"""Target Web Application package (Student Grade Portal)."""
