"""
app.py - Web Demo 2 chế độ: Website Quản lý Điểm Sinh viên (VULNERABLE / HARDENED).
Owned by Sơn (target_web/ cổng 8000): minh họa trực tiếp lập trình an toàn (Prepared Statements,
HTML output encoding, realpath Traversal Sandbox) song hành cùng phòng thủ tầng biên Mini-WAF.
"""

from __future__ import annotations

import html
import os
import sqlite3
from pathlib import Path

from fastapi import FastAPI, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
import uvicorn


STUDENT_SEED = [
    ("SV001", "Nguyen Van An", "AT19A", 8.8, "An toan mang"),
    ("SV002", "Patrick O'Brien", "AT19A", 9.1, "Bao mat Web"),
    ("SV003", "Marco D'Angelo", "AT19B", 8.4, "Mat ma hoc"),
    ("SV004", "Tran Thi Binh", "AT19B", 7.9, "He dieu hanh"),
    ("SV005", "Le Minh Khanh", "AT19A", 9.4, "Kiem thu xam nhap"),
]


def normalize_app_mode(raw: str | None) -> str:
    val = (raw or "VULNERABLE").strip().upper()
    if val in ("HARDENED", "SECURE"):
        return "HARDENED"
    return "VULNERABLE"


def _init_db(db_path: Path, docs_dir: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    docs_dir.mkdir(parents=True, exist_ok=True)
    (docs_dir / "tailieu.pdf").write_text("%PDF-1.4\n% Student Handbook - AT19\n", encoding="utf-8")
    (docs_dir / "huongdan.txt").write_text("Huong dan xem diem & tai tai lieu mon ATTT.\n", encoding="utf-8")

    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS students (
                masv TEXT PRIMARY KEY,
                fullname TEXT NOT NULL,
                class_name TEXT NOT NULL,
                gpa REAL NOT NULL,
                note TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            )
            """
        )
        for row in STUDENT_SEED:
            conn.execute(
                "INSERT OR IGNORE INTO students (masv, fullname, class_name, gpa, note) VALUES (?, ?, ?, ?, ?)",
                row,
            )
        conn.execute(
            "INSERT OR IGNORE INTO accounts (username, password, role) VALUES ('admin', 'portal_admin_2026', 'lecturer')"
        )
        conn.execute(
            "INSERT OR IGNORE INTO accounts (username, password, role) VALUES ('sv001', 'student123', 'student')"
        )
        conn.commit()
    finally:
        conn.close()


def create_target_app(
    db_path: str | Path | None = None,
    docs_dir: str | Path | None = None,
    security_mode: str | None = None,
) -> FastAPI:
    resolved_db = Path(db_path or os.getenv("DB_PATH", "/tmp/student_portal.db"))
    resolved_docs = Path(docs_dir or "/tmp/portal_docs")
    mode = normalize_app_mode(security_mode or os.getenv("APP_SECURITY_MODE", "VULNERABLE"))
    _init_db(resolved_db, resolved_docs)

    app = FastAPI(title="Website Quản lý Điểm Sinh viên", docs_url=None, redoc_url=None)
    app.state.backend_requests_received = 0
    app.state.received_log: list[str] = []
    app.state.security_mode = mode  # "VULNERABLE" | "HARDENED"

    @app.middleware("http")
    async def count_hits_and_legacy_headers(request: Request, call_next):
        if request.url.path != "/internal-stats":
            app.state.backend_requests_received += 1
            app.state.received_log.append(f"{request.method} {request.url.path}?{request.url.query}")
            if len(app.state.received_log) > 200:
                app.state.received_log.pop(0)
        response = await call_next(request)
        if app.state.security_mode == "VULNERABLE":
            response.headers["Server"] = "StudentPortal-Apache-Dev/2.4.25 (Debian)"
            response.headers["X-Powered-By"] = "Python-Legacy/3.11"
        else:
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
        return response

    @app.get("/", response_class=HTMLResponse)
    async def home() -> HTMLResponse:
        resp = HTMLResponse(
            f"<h1>Cổng Quản lý Điểm Sinh viên ({app.state.security_mode})</h1>"
            "<p>Endpoints: /search, /grades, /login, /comments, /download</p>"
        )
        if app.state.security_mode == "HARDENED":
            resp.set_cookie(key="portal_session", value="demo-session-token", httponly=True, samesite="lax")
        else:
            resp.set_cookie(key="portal_session", value="demo-session-token")
        return resp

    @app.get("/internal-stats")
    async def internal_stats() -> JSONResponse:
        return JSONResponse(
            {
                "backend_requests_received": app.state.backend_requests_received,
                "security_mode": app.state.security_mode,
                "recent": app.state.received_log[-20:],
            }
        )

    @app.post("/login")
    async def login(request: Request) -> JSONResponse:
        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            data = await request.json()
        else:
            form = await request.form()
            data = dict(form)

        username = str(data.get("username", ""))
        password = str(data.get("password", ""))
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            if app.state.security_mode == "VULNERABLE":
                sql = f"SELECT username, role FROM accounts WHERE username = '{username}' AND password = '{password}'"
                try:
                    row = conn.execute(sql).fetchone()
                except sqlite3.Error as exc:
                    return JSONResponse(status_code=500, content={"error": f"SQLite syntax error: {exc}"})
            else:
                row = conn.execute(
                    "SELECT username, role FROM accounts WHERE username = ? AND password = ?",
                    (username, password),
                ).fetchone()
        finally:
            conn.close()

        if row:
            resp = JSONResponse({"authenticated": True, "username": row["username"], "role": row["role"]})
            if app.state.security_mode == "HARDENED":
                resp.set_cookie(key="portal_session", value=f"uid-{row['username']}", httponly=True, samesite="lax")
            else:
                resp.set_cookie(key="portal_session", value=f"uid-{row['username']}")
            return resp
        return JSONResponse(status_code=401, content={"authenticated": False})

    @app.get("/search")
    async def search_students(q: str = Query(default="")) -> JSONResponse:
        # Parameterized search handles apostrophes cleanly (Patrick O'Brien)
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            like_q = f"%{q}%"
            rows = [
                dict(r)
                for r in conn.execute(
                    "SELECT masv, fullname, class_name, gpa FROM students WHERE masv = ? OR fullname LIKE ?",
                    (q, like_q),
                ).fetchall()
            ]
        finally:
            conn.close()
        return JSONResponse({"query": q, "count": len(rows), "students": rows})

    @app.get("/grades")
    async def get_grades(masv: str = Query(default="SV001")) -> JSONResponse:
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            if app.state.security_mode == "VULNERABLE":
                sql = f"SELECT masv, fullname, class_name, gpa FROM students WHERE masv = '{masv}'"
                try:
                    rows = [dict(r) for r in conn.execute(sql).fetchall()]
                except sqlite3.Error as exc:
                    return JSONResponse(status_code=500, content={"error": f"SQL syntax error: {exc}"})
            else:
                rows = [
                    dict(r)
                    for r in conn.execute(
                        "SELECT masv, fullname, class_name, gpa FROM students WHERE masv = ?",
                        (masv,),
                    ).fetchall()
                ]
        finally:
            conn.close()
        return JSONResponse({"query": masv, "count": len(rows), "students": rows})

    @app.post("/comments", response_class=HTMLResponse)
    @app.get("/comments", response_class=HTMLResponse)
    async def comments_endpoint(author: str = Query(default="Sinh vien"), msg: str = Query(default="")) -> HTMLResponse:
        if not msg:
            return HTMLResponse("<div>Binh luan mon hoc: an toan &amp; sach</div>")
        if app.state.security_mode == "HARDENED":
            return HTMLResponse(f"<div><b>{html.escape(author)}</b>: {html.escape(msg)}</div>")
        return HTMLResponse(f"<div><b>{author}</b>: {msg}</div>")

    @app.get("/download", response_class=PlainTextResponse)
    async def download_file(file: str = Query(default="tailieu.pdf")) -> PlainTextResponse:
        if app.state.security_mode == "HARDENED":
            candidate = (resolved_docs / file).resolve()
            if resolved_docs.resolve() not in candidate.parents or not candidate.is_file():
                return PlainTextResponse("400 Invalid file path (sandboxed)", status_code=400)
            return PlainTextResponse(candidate.read_text(encoding="utf-8", errors="replace"))

        candidate = resolved_docs / file
        if not candidate.exists() or not candidate.is_file():
            return PlainTextResponse("File not found", status_code=404)
        return PlainTextResponse(candidate.read_text(encoding="utf-8", errors="replace"))

    return app


if __name__ == "__main__":
    target_app = create_target_app()
    uvicorn.run(target_app, host="0.0.0.0", port=int(os.getenv("PORT", "8000")), log_level="warning")
