"""
app.py - Web Demo 2 chế độ: Website Quản lý Điểm Sinh viên (VULNERABLE / HARDENED).
Owned by Sơn (target_web/ cổng 8000): cung cấp đầy đủ cả Giao diện Web HTML trực quan tại GET /
lẫn API JSON phục vụ kiểm thử tự động & benchmark, hỗ trợ chuyển đổi VULNERABLE / HARDENED.
"""

from __future__ import annotations

import html
import os
import sqlite3
from pathlib import Path

from fastapi import FastAPI, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
import uvicorn


STUDENT_SEED = [
    ("SV001", "Nguyen Van An", "AT19A", 8.8, "An toan mang"),
    ("SV002", "Patrick O'Brien", "AT19A", 9.1, "Bao mat Web"),
    ("SV003", "Marco D'Angelo", "AT19B", 8.4, "Mat ma hoc"),
    ("SV004", "Tran Thi Binh", "AT19B", 7.9, "He dieu hanh"),
    ("SV005", "Le Minh Khanh", "AT19A", 9.4, "Kiem thu xam nhap"),
]

PORTAL_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Website Quản lý Điểm Sinh viên — Khoa ATTT</title>
  <style>
    :root {{ --bg:#f8fafc; --card:#ffffff; --border:#e2e8f0; --text:#0f172a; --muted:#475569; --accent:#2563eb; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; font-family: system-ui, -apple-system, sans-serif; background:var(--bg); color:var(--text); font-size:14px; }}
    header {{ background:#0f172a; color:#fff; padding:14px 20px; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:10px; }}
    .badge {{ display:inline-block; padding:4px 10px; border-radius:999px; font-family:ui-monospace,monospace; font-size:12px; font-weight:700; }}
    .b-vuln {{ background:#fef3c7; color:#92400e; }}
    .b-hard {{ background:#dcfce7; color:#166534; }}
    .wrap {{ max-width:1080px; margin:20px auto; padding:0 16px; display:grid; gap:16px; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); }}
    .card {{ background:var(--card); border:1px solid var(--border); border-radius:10px; padding:16px; }}
    h2 {{ margin:0 0 8px; font-size:16px; }}
    .row {{ display:flex; gap:8px; margin-bottom:10px; }}
    input {{ flex:1; padding:8px 10px; border:1px solid var(--border); border-radius:6px; font-family:ui-monospace,monospace; font-size:13px; }}
    button {{ cursor:pointer; background:var(--accent); color:#fff; border:none; border-radius:6px; padding:8px 14px; font-weight:600; font-size:13px; }}
    button.sec {{ background:#334155; }}
    table {{ width:100%; border-collapse:collapse; font-size:13px; margin-top:8px; }}
    th, td {{ text-align:left; padding:7px 6px; border-bottom:1px solid var(--border); }}
    pre {{ background:#0f172a; color:#e2e8f0; padding:10px; border-radius:6px; overflow:auto; font-size:12px; margin:8px 0 0; }}
  </style>
</head>
<body>
  <header>
    <div>
      <strong>CỔNG QUẢN LÝ ĐIỂM SINH VIÊN · ĐẠI HỌC ATTT</strong>
      <div style="font-size:12px;color:#cbd5e1;">Ứng dụng Web Mục tiêu (:8000 nội bộ) · Bảo vệ qua Mini-WAF (:8080)</div>
    </div>
    <span class="badge {badge_cls}">APP_SECURITY_MODE: {sec_mode}</span>
  </header>

  <div class="wrap">
    <div class="card">
      <h2>1. Tra cứu Sinh viên &amp; Bảng điểm (/search · /grades)</h2>
      <div class="row">
        <input id="qSearch" value="SV001" placeholder="Nhập mã SV hoặc họ tên (vd: O'Brien)" />
        <button onclick="runSearch()">Tìm kiếm</button>
        <button class="sec" onclick="runGrades()">Tra theo Mã SV</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px;">
        <button class="sec" onclick="qSearch.value=&quot;O'Brien&quot;;runSearch()">O'Brien</button>
        <button class="sec" onclick="qSearch.value=&quot;1' OR 1=1--&quot;;runGrades()">' OR 1=1--</button>
        <button class="sec" onclick="qSearch.value=&quot;1' UN/**/ION SEL/**/ECT 1,2,3,4--&quot;;runSearch()">UN/**/ION</button>
      </div>
      <div id="searchOut"></div>
    </div>

    <div class="card">
      <h2>2. Đăng nhập Giảng viên / Sinh viên (/login)</h2>
      <div class="row"><input id="uLogin" value="sv001" placeholder="username" /><input id="pLogin" value="student123" placeholder="password" /></div>
      <div class="row">
        <button onclick="runLogin()">Đăng nhập</button>
        <button class="sec" onclick="uLogin.value=&quot;admin' OR '1'='1'--&quot;;runLogin()">Thử SQLi Bypass</button>
      </div>
      <pre id="loginOut">Sẵn sàng đăng nhập (sv001 / student123).</pre>
    </div>

    <div class="card">
      <h2>3. Bình luận Môn học (/comments)</h2>
      <div class="row"><input id="cAuthor" value="Minh" style="max-width:110px;" /><input id="cMsg" value="5 < 10 và điểm >= 8.0" /></div>
      <div class="row">
        <button onclick="runComment()">Gửi bình luận</button>
        <button class="sec" onclick="cMsg.value='<img src=x onerror=alert(1)>';runComment()">Thử XSS</button>
      </div>
      <div id="commentOut" style="border:1px dashed var(--border);padding:10px;border-radius:6px;min-height:42px;"></div>
    </div>

    <div class="card">
      <h2>4. Kho Tài liệu Học tập (/download)</h2>
      <div class="row"><input id="dFile" value="tailieu.pdf" /><button onclick="runDownload()">Tải tài liệu</button></div>
      <div style="display:flex;gap:6px;margin-bottom:8px;">
        <button class="sec" onclick="dFile.value='tailieu.pdf';runDownload()">tailieu.pdf</button>
        <button class="sec" onclick="dFile.value='../../etc/passwd';runDownload()">../../etc/passwd</button>
      </div>
      <pre id="dlOut">Chọn tệp để đọc nội dung.</pre>
    </div>
  </div>

  <script>
    async function runSearch() {{
      const r = await fetch('/search?q=' + encodeURIComponent(qSearch.value));
      const txt = await r.text();
      if (!r.ok) {{ searchOut.innerHTML = '<pre>HTTP ' + r.status + ': ' + txt + '</pre>'; return; }}
      const d = JSON.parse(txt);
      searchOut.innerHTML = '<table><tr><th>Mã SV</th><th>Họ tên</th><th>Lớp</th><th>GPA</th></tr>' +
        (d.students||[]).map(s => `<tr><td>${{s.masv}}</td><td>${{s.fullname}}</td><td>${{s.class_name}}</td><td><b>${{s.gpa}}</b></td></tr>`).join('') + '</table>';
    }}
    async function runGrades() {{
      const r = await fetch('/grades?masv=' + encodeURIComponent(qSearch.value));
      const txt = await r.text();
      searchOut.innerHTML = '<pre>HTTP ' + r.status + '\\n' + txt + '</pre>';
    }}
    async function runLogin() {{
      const r = await fetch('/login', {{ method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify({{username:uLogin.value,password:pLogin.value}}) }});
      loginOut.textContent = 'HTTP ' + r.status + '\\n' + await r.text();
    }}
    async function runComment() {{
      const r = await fetch('/comments?author=' + encodeURIComponent(cAuthor.value) + '&msg=' + encodeURIComponent(cMsg.value));
      commentOut.innerHTML = 'HTTP ' + r.status + ': ' + await r.text();
    }}
    async function runDownload() {{
      const r = await fetch('/download?file=' + encodeURIComponent(dFile.value));
      dlOut.textContent = 'HTTP ' + r.status + '\\n' + await r.text();
    }}
    runSearch();
  </script>
</body>
</html>"""


def normalize_app_mode(raw: str | None) -> str:
    val = (raw or "VULNERABLE").strip().upper()
    if val in ("HARDENED", "SECURE"):
        return "HARDENED"
    return "VULNERABLE"


def _init_db(db_path: Path, docs_dir: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    docs_dir.mkdir(parents=True, exist_ok=True)
    (docs_dir / "tailieu.pdf").write_text("%PDF-1.4\n% Student Handbook - AT19\n", encoding="utf-8")
    (docs_dir / "huongdan.txt").write_text("Huong dan xem diem & tai tai lieu mon ATTT.\n", encoding="utf-8")

    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS students (
                masv TEXT PRIMARY KEY,
                fullname TEXT NOT NULL,
                class_name TEXT NOT NULL,
                gpa REAL NOT NULL,
                note TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            )
            """
        )
        for row in STUDENT_SEED:
            conn.execute(
                "INSERT OR IGNORE INTO students (masv, fullname, class_name, gpa, note) VALUES (?, ?, ?, ?, ?)",
                row,
            )
        conn.execute(
            "INSERT OR IGNORE INTO accounts (username, password, role) VALUES ('admin', 'portal_admin_2026', 'lecturer')"
        )
        conn.execute(
            "INSERT OR IGNORE INTO accounts (username, password, role) VALUES ('sv001', 'student123', 'student')"
        )
        conn.commit()
    finally:
        conn.close()


def create_target_app(
    db_path: str | Path | None = None,
    docs_dir: str | Path | None = None,
    security_mode: str | None = None,
) -> FastAPI:
    resolved_db = Path(db_path or os.getenv("DB_PATH", "/tmp/student_portal.db"))
    resolved_docs = Path(docs_dir or "/tmp/portal_docs")
    mode = normalize_app_mode(security_mode or os.getenv("APP_SECURITY_MODE", "VULNERABLE"))
    _init_db(resolved_db, resolved_docs)

    app = FastAPI(title="Website Quản lý Điểm Sinh viên", docs_url=None, redoc_url=None)
    app.state.backend_requests_received = 0
    app.state.received_log: list[str] = []
    app.state.security_mode = mode  # "VULNERABLE" | "HARDENED"

    @app.middleware("http")
    async def count_hits_and_legacy_headers(request: Request, call_next):
        if request.url.path != "/internal-stats":
            app.state.backend_requests_received += 1
            app.state.received_log.append(f"{request.method} {request.url.path}?{request.url.query}")
            if len(app.state.received_log) > 200:
                app.state.received_log.pop(0)
        response = await call_next(request)
        if app.state.security_mode == "VULNERABLE":
            response.headers["Server"] = "StudentPortal-Apache-Dev/2.4.25 (Debian)"
            response.headers["X-Powered-By"] = "Python-Legacy/3.11"
        else:
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
        return response

    @app.get("/", response_class=HTMLResponse)
    async def home() -> HTMLResponse:
        badge_cls = "b-hard" if app.state.security_mode == "HARDENED" else "b-vuln"
        resp = HTMLResponse(
            PORTAL_HTML_TEMPLATE.format(sec_mode=app.state.security_mode, badge_cls=badge_cls)
        )
        if app.state.security_mode == "HARDENED":
            resp.set_cookie(key="portal_session", value="demo-session-token", httponly=True, samesite="lax")
        else:
            resp.set_cookie(key="portal_session", value="demo-session-token")
        return resp

    @app.get("/internal-stats")
    async def internal_stats() -> JSONResponse:
        return JSONResponse(
            {
                "backend_requests_received": app.state.backend_requests_received,
                "security_mode": app.state.security_mode,
                "recent": app.state.received_log[-20:],
            }
        )

    @app.post("/login")
    async def login(request: Request) -> JSONResponse:
        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            data = await request.json()
        else:
            form = await request.form()
            data = dict(form)

        username = str(data.get("username", ""))
        password = str(data.get("password", ""))
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            if app.state.security_mode == "VULNERABLE":
                sql = f"SELECT username, role FROM accounts WHERE username = '{username}' AND password = '{password}'"
                try:
                    row = conn.execute(sql).fetchone()
                except sqlite3.Error as exc:
                    return JSONResponse(status_code=500, content={"error": f"SQLite syntax error: {exc}"})
            else:
                row = conn.execute(
                    "SELECT username, role FROM accounts WHERE username = ? AND password = ?",
                    (username, password),
                ).fetchone()
        finally:
            conn.close()

        if row:
            resp = JSONResponse({"authenticated": True, "username": row["username"], "role": row["role"]})
            if app.state.security_mode == "HARDENED":
                resp.set_cookie(key="portal_session", value=f"uid-{row['username']}", httponly=True, samesite="lax")
            else:
                resp.set_cookie(key="portal_session", value=f"uid-{row['username']}")
            return resp
        return JSONResponse(status_code=401, content={"authenticated": False})

    @app.get("/search")
    async def search_students(q: str = Query(default="")) -> JSONResponse:
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            like_q = f"%{q}%"
            rows = [
                dict(r)
                for r in conn.execute(
                    "SELECT masv, fullname, class_name, gpa FROM students WHERE masv = ? OR fullname LIKE ?",
                    (q, like_q),
                ).fetchall()
            ]
        finally:
            conn.close()
        return JSONResponse({"query": q, "count": len(rows), "students": rows})

    @app.get("/grades")
    async def get_grades(masv: str = Query(default="SV001")) -> JSONResponse:
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            if app.state.security_mode == "VULNERABLE":
                sql = f"SELECT masv, fullname, class_name, gpa FROM students WHERE masv = '{masv}'"
                try:
                    rows = [dict(r) for r in conn.execute(sql).fetchall()]
                except sqlite3.Error as exc:
                    return JSONResponse(status_code=500, content={"error": f"SQL syntax error: {exc}"})
            else:
                rows = [
                    dict(r)
                    for r in conn.execute(
                        "SELECT masv, fullname, class_name, gpa FROM students WHERE masv = ?",
                        (masv,),
                    ).fetchall()
                ]
        finally:
            conn.close()
        return JSONResponse({"query": masv, "count": len(rows), "students": rows})

    @app.post("/comments", response_class=HTMLResponse)
    @app.get("/comments", response_class=HTMLResponse)
    async def comments_endpoint(author: str = Query(default="Sinh vien"), msg: str = Query(default="")) -> HTMLResponse:
        if not msg:
            return HTMLResponse("<div>Binh luan mon hoc: an toan &amp; sach</div>")
        if app.state.security_mode == "HARDENED":
            return HTMLResponse(f"<div><b>{html.escape(author)}</b>: {html.escape(msg)}</div>")
        return HTMLResponse(f"<div><b>{author}</b>: {msg}</div>")

    @app.get("/download", response_class=PlainTextResponse)
    async def download_file(file: str = Query(default="tailieu.pdf")) -> PlainTextResponse:
        if app.state.security_mode == "HARDENED":
            candidate = (resolved_docs / file).resolve()
            if resolved_docs.resolve() not in candidate.parents or not candidate.is_file():
                return PlainTextResponse("400 Invalid file path (sandboxed)", status_code=400)
            return PlainTextResponse(candidate.read_text(encoding="utf-8", errors="replace"))

        candidate = resolved_docs / file
        if not candidate.exists() or not candidate.is_file():
            return PlainTextResponse("File not found", status_code=404)
        return PlainTextResponse(candidate.read_text(encoding="utf-8", errors="replace"))

    return app


if __name__ == "__main__":
    target_app = create_target_app()
    uvicorn.run(target_app, host="0.0.0.0", port=int(os.getenv("PORT", "8000")), log_level="warning")
