"""
app.py - Web Demo 2 chế độ: Website Quản lý Điểm Sinh viên (VULNERABLE / HARDENED).
Owned by Sơn (target_web/ cổng 8000): cung cấp đầy đủ cả Giao diện Web HTML trực quan tại GET /
lẫn API JSON phục vụ kiểm thử tự động & benchmark, hỗ trợ chuyển đổi VULNERABLE / HARDENED.
"""

from __future__ import annotations

import html
import json
import os
import sqlite3
from pathlib import Path

from fastapi import FastAPI, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
import uvicorn


_FALLBACK_SEED = [
    ("SV001", "Nguyen Van An", "ANHTTT", 8.8, "Mật mã học ứng dụng"),
    ("SV002", "Patrick O'Brien", "ANHTTT", 9.1, "An toàn hệ thống mạng"),
    ("SV003", "Marco D'Angelo", "BĐATTT", 8.4, "Bảo đảm an toàn dữ liệu"),
    ("SV004", "Tran Thi Binh", "CNTT1", 7.9, "Hệ điều hành Linux"),
    ("SV005", "Le Minh Khanh", "KTPM", 9.4, "Kiến trúc phần mềm"),
]


def _load_student_seed() -> list[tuple[str, str, str, float, str]]:
    seed_file = Path(__file__).with_name("students_seed.json")
    if seed_file.is_file():
        data = json.loads(seed_file.read_text(encoding="utf-8"))
        return [
            (r["masv"], r["fullname"], r["className"], float(r["gpa"]), r["note"])
            for r in data
        ]
    return list(_FALLBACK_SEED)


STUDENT_SEED = _load_student_seed()

PORTAL_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Cổng Thông tin Đào tạo — Học viện Kỹ thuật Quân sự (MTA)</title>
  <style>
    :root { --green:#005F37; --dark-green:#004528; --mint:#F2F9F6; --mint-border:#E6EFEB; --amber:#FBBF24; --peach:#FFEED0; --navy:#0a1d35; --text:#1e293b; }
    * { box-sizing:border-box; }
    body { margin:0; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; background:#fff; color:var(--text); font-size:14px; }
    .util { background:var(--dark-green); color:#d1fae5; padding:6px 24px; font-size:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; }
    header { background:var(--green); color:#fff; padding:12px 24px; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:12px; box-shadow:0 2px 10px rgba(0,0,0,.15); }
    .brand { display:flex; align-items:center; gap:12px; }
    .brand-title { font-weight:800; font-size:16px; letter-spacing:.03em; }
    .brand-sub { font-size:11px; font-weight:700; color:var(--amber); letter-spacing:.1em; text-transform:uppercase; }
    nav a { color:#fff; text-decoration:none; font-size:13px; font-weight:600; padding:6px 10px; border-radius:6px; }
    nav a:hover { background:rgba(255,255,255,.15); }
    .hero { background:linear-gradient(135deg, #004b2b 0%, #065f46 55%, #132a46 100%); color:#fff; padding:34px 24px; }
    .hero-inner { max-width:1120px; margin:0 auto; }
    .hero h1 { margin:8px 0 8px; font-size:32px; font-weight:800; }
    .hero p { margin:0 0 16px; max-width:680px; color:#d1fae5; line-height:1.5; }
    .wrap { max-width:1120px; margin:24px auto; padding:0 16px; }
    .quick-grid { display:grid; gap:14px; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); margin-bottom:22px; }
    .quick-card { display:flex; gap:12px; align-items:flex-start; background:var(--mint); border:1px solid var(--mint-border); border-radius:12px; padding:14px; }
    .q-icon { width:42px; height:42px; border-radius:999px; background:var(--peach); color:var(--green); display:flex; align-items:center; justify-content:center; font-weight:800; flex-shrink:0; }
    .portal-grid { display:grid; gap:16px; grid-template-columns:repeat(auto-fit, minmax(340px, 1fr)); }
    .card { background:#fff; border:1px solid var(--mint-border); border-radius:12px; padding:18px; box-shadow:0 1px 3px rgba(0,0,0,.04); }
    h2 { margin:0 0 12px; font-size:15px; color:var(--green); border-left:4px solid var(--amber); padding-left:10px; }
    .row { display:flex; gap:8px; margin-bottom:10px; flex-wrap:wrap; }
    input { flex:1; min-width:160px; padding:8px 10px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; }
    button { cursor:pointer; background:var(--green); color:#fff; border:none; border-radius:8px; padding:8px 14px; font-weight:600; font-size:13px; }
    button:hover { background:#004a2b; }
    button.sec { background:var(--mint); color:var(--green); border:1px solid var(--mint-border); }
    button.sec:hover { background:#e2f3ec; }
    table { width:100%; border-collapse:collapse; font-size:13px; margin-top:8px; }
    th { background:var(--mint); color:var(--green); text-align:left; padding:8px; }
    td { padding:8px; border-bottom:1px solid #f1f5f9; }
    pre { background:#f8fafc; border:1px solid #e2e8f0; color:#1e293b; padding:10px; border-radius:8px; overflow:auto; font-size:12px; margin:8px 0 0; }
    footer { background:var(--green); color:#d1fae5; padding:16px 24px; margin-top:28px; font-size:12px; }
    .foot-inner { max-width:1120px; margin:0 auto; display:flex; flex-wrap:wrap; justify-content:space-between; gap:16px; }
  </style>
</head>
<body>
  <div class="util">
    <span>Welcome to MTA &nbsp;|&nbsp; Cổng Thông tin Đào tạo Sinh viên</span>
    <span>CS1: 236 Hoàng Quốc Việt, Hà Nội &nbsp;|&nbsp; VN</span>
  </div>
  <header>
    <div class="brand">
      <svg width="44" height="44" viewBox="0 0 64 64" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill="#005F37" stroke="#FBBF24" stroke-width="2.5"/>
        <ellipse cx="32" cy="32" rx="16" ry="6.5" fill="none" stroke="#FBBF24" stroke-width="1.4" transform="rotate(-32 32 32)"/>
        <ellipse cx="32" cy="32" rx="16" ry="6.5" fill="none" stroke="#34D399" stroke-width="1.4" transform="rotate(32 32 32)"/>
        <polygon points="32,16 35.4,26.2 46,26.2 37.5,32.5 40.7,42.8 32,36.6 23.3,42.8 26.5,32.5 18,26.2 28.6,26.2" fill="#FBBF24"/>
      </svg>
      <div>
        <div class="brand-title">HỌC VIỆN KỸ THUẬT QUÂN SỰ</div>
        <div class="brand-sub">MILITARY TECHNICAL ACADEMY · CỔNG ĐÀO TẠO</div>
      </div>
    </div>
    <nav>
      <a href="#grades-sec">Tra cứu Điểm</a>
      <a href="#login-sec">Đăng nhập SV</a>
      <a href="#qa-sec">Hỏi đáp</a>
      <a href="#docs-sec">Tài liệu</a>
    </nav>
  </header>

  <section class="hero">
    <div class="hero-inner">
      <h1>Trí tuệ tỏa sáng</h1>
    </div>
  </section>

  <main class="wrap">
    <div class="quick-grid">
      <div class="quick-card"><div class="q-icon">01</div><div><strong style="color:#005F37">Đào tạo &amp; Bảng điểm</strong></div></div>
      <div class="quick-card"><div class="q-icon">02</div><div><strong style="color:#005F37">Đăng nhập Học viên</strong></div></div>
      <div class="quick-card"><div class="q-icon">03</div><div><strong style="color:#005F37">Tài liệu Học phần</strong></div></div>
    </div>

    <div class="portal-grid">
      <div class="card" id="grades-sec">
        <h2>Tra cứu Điểm Học phần</h2>
        <div class="row">
          <input id="qSearch" value="" placeholder="Mã SV, họ tên hoặc lớp..." />
          <select id="clsFilter" onchange="runSearch()" style="padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;background:var(--mint);color:var(--green);font-weight:600;">
            <option value="">Tất cả lớp (402)</option>
            <option value="ANHTTT">ANHTTT (54)</option>
            <option value="CNTT1">CNTT1 (46)</option>
            <option value="CNTT2">CNTT2 (46)</option>
            <option value="TT">TT (45)</option>
            <option value="CNTT3">CNTT3 (22)</option>
            <option value="TLPK2">TLPK2 (18)</option>
            <option value="TLPK1">TLPK1 (17)</option>
            <option value="PTDL">PTDL (16)</option>
            <option value="BĐATTT">BĐATTT (16)</option>
            <option value="TTNT">TTNT (15)</option>
            <option value="KTPM">KTPM (8)</option>
          </select>
          <button onclick="runSearch()">Tra cứu</button>
        </div>
        <div id="searchMeta" style="font-size:12px;color:#475569;margin-bottom:6px;"></div>
        <div id="searchOut"></div>
      </div>

      <div class="card" id="login-sec">
        <h2>Đăng nhập Hệ thống</h2>
        <div class="row"><input id="uLogin" value="sv001" placeholder="Tên đăng nhập" /><input id="pLogin" type="password" value="student123" placeholder="Mật khẩu" /></div>
        <div class="row">
          <button onclick="runLogin()">Đăng nhập</button>
        </div>
        <pre id="loginOut"></pre>
      </div>

      <div class="card" id="qa-sec">
        <h2>Hỏi đáp Giáo vụ</h2>
        <div class="row"><input id="cAuthor" value="Nguyen Van An" style="max-width:130px;" /><input id="cMsg" placeholder="Nội dung câu hỏi..." /></div>
        <div class="row">
          <button onclick="runComment()">Gửi</button>
        </div>
        <div id="commentOut" style="border:1px solid var(--mint-border);padding:10px;border-radius:8px;min-height:42px;background:var(--mint);"></div>
      </div>

      <div class="card" id="docs-sec">
        <h2>Kho Tài liệu</h2>
        <div class="row">
          <button class="sec" onclick="runDownload('tailieu.pdf')">Quy chế Đào tạo 2026 (PDF)</button>
          <button class="sec" onclick="runDownload('huongdan.txt')">Hướng dẫn Tra cứu Điểm (TXT)</button>
        </div>
        <pre id="dlOut"></pre>
      </div>
    </div>
  </main>

  <footer>
    <div class="foot-inner">
      <span><strong>Học viện Kỹ thuật Quân sự</strong></span>
      <span>info@mta.edu.vn · 236 Hoàng Quốc Việt, Hà Nội</span>
    </div>
  </footer>

  <script>
    async function runSearch() {
      const url = '/search?q=' + encodeURIComponent(qSearch.value) + '&cls=' + encodeURIComponent(clsFilter.value) + '&limit=25';
      const r = await fetch(url);
      const txt = await r.text();
      if (!r.ok) { searchMeta.textContent = ''; searchOut.innerHTML = '<pre>HTTP ' + r.status + ': ' + txt + '</pre>'; return; }
      const d = JSON.parse(txt);
      searchMeta.textContent = `Hiển thị ${(d.students||[]).length} / tổng ${d.total_matched ?? d.count} hồ sơ phù hợp`;
      searchOut.innerHTML = '<table><tr><th>Mã SV</th><th>Họ tên</th><th>Lớp CN</th><th>GPA</th><th>Học phần</th></tr>' +
        (d.students||[]).map(s => `<tr><td>${s.masv}</td><td>${s.fullname}</td><td>${s.class_name}</td><td><b>${s.gpa}</b></td><td>${s.note||''}</td></tr>`).join('') + '</table>';
    }
    async function runLogin() {
      const r = await fetch('/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username:uLogin.value,password:pLogin.value}) });
      loginOut.textContent = await r.text();
    }
    async function runComment() {
      const r = await fetch('/comments?author=' + encodeURIComponent(cAuthor.value) + '&msg=' + encodeURIComponent(cMsg.value));
      commentOut.innerHTML = await r.text();
    }
    async function runDownload(fileName) {
      const r = await fetch('/download?file=' + encodeURIComponent(fileName));
      dlOut.textContent = await r.text();
    }
    runSearch();
  </script>
</body>
</html>"""


def normalize_app_mode(raw: str | None) -> str:
    val = (raw or "VULNERABLE").strip().upper()
    if val in ("HARDENED", "SECURE"):
        return "HARDENED"
    return "VULNERABLE"


def _init_db(db_path: Path, docs_dir: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    docs_dir.mkdir(parents=True, exist_ok=True)
    (docs_dir / "tailieu.pdf").write_text("%PDF-1.4\n% Student Handbook - AT19\n", encoding="utf-8")
    (docs_dir / "huongdan.txt").write_text("Huong dan xem diem & tai tai lieu mon ATTT.\n", encoding="utf-8")

    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS students (
                masv TEXT PRIMARY KEY,
                fullname TEXT NOT NULL,
                class_name TEXT NOT NULL,
                gpa REAL NOT NULL,
                note TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            )
            """
        )
        conn.executemany(
            "INSERT OR REPLACE INTO students (masv, fullname, class_name, gpa, note) VALUES (?, ?, ?, ?, ?)",
            STUDENT_SEED,
        )
        conn.execute(
            "INSERT OR IGNORE INTO accounts (username, password, role) VALUES ('admin', 'portal_admin_2026', 'lecturer')"
        )
        conn.execute(
            "INSERT OR IGNORE INTO accounts (username, password, role) VALUES ('sv001', 'student123', 'student')"
        )
        conn.commit()
    finally:
        conn.close()


def create_target_app(
    db_path: str | Path | None = None,
    docs_dir: str | Path | None = None,
    security_mode: str | None = None,
) -> FastAPI:
    resolved_db = Path(db_path or os.getenv("DB_PATH", "/tmp/student_portal.db"))
    resolved_docs = Path(docs_dir or "/tmp/portal_docs")
    mode = normalize_app_mode(security_mode or os.getenv("APP_SECURITY_MODE", "VULNERABLE"))
    _init_db(resolved_db, resolved_docs)

    app = FastAPI(title="Website Quản lý Điểm Sinh viên", docs_url=None, redoc_url=None)
    app.state.backend_requests_received = 0
    app.state.received_log: list[str] = []
    app.state.security_mode = mode  # "VULNERABLE" | "HARDENED"

    @app.middleware("http")
    async def count_hits_and_legacy_headers(request: Request, call_next):
        if request.url.path != "/internal-stats":
            app.state.backend_requests_received += 1
            app.state.received_log.append(f"{request.method} {request.url.path}?{request.url.query}")
            if len(app.state.received_log) > 200:
                app.state.received_log.pop(0)
        response = await call_next(request)
        if app.state.security_mode == "VULNERABLE":
            response.headers["Server"] = "StudentPortal-Apache-Dev/2.4.25 (Debian)"
            response.headers["X-Powered-By"] = "Python-Legacy/3.11"
        else:
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
        return response

    @app.get("/", response_class=HTMLResponse)
    async def home() -> HTMLResponse:
        resp = HTMLResponse(PORTAL_HTML_TEMPLATE)
        if app.state.security_mode == "HARDENED":
            resp.set_cookie(key="portal_session", value="demo-session-token", httponly=True, samesite="lax")
        else:
            resp.set_cookie(key="portal_session", value="demo-session-token")
        return resp

    @app.get("/internal-stats")
    async def internal_stats() -> JSONResponse:
        return JSONResponse(
            {
                "backend_requests_received": app.state.backend_requests_received,
                "security_mode": app.state.security_mode,
                "recent": app.state.received_log[-20:],
            }
        )

    @app.post("/login")
    async def login(request: Request) -> JSONResponse:
        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            data = await request.json()
        else:
            form = await request.form()
            data = dict(form)

        username = str(data.get("username", ""))
        password = str(data.get("password", ""))
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            if app.state.security_mode == "VULNERABLE":
                sql = f"SELECT username, role FROM accounts WHERE username = '{username}' AND password = '{password}'"
                try:
                    row = conn.execute(sql).fetchone()
                except sqlite3.Error as exc:
                    return JSONResponse(status_code=500, content={"error": f"SQLite syntax error: {exc}"})
            else:
                row = conn.execute(
                    "SELECT username, role FROM accounts WHERE username = ? AND password = ?",
                    (username, password),
                ).fetchone()
        finally:
            conn.close()

        if row:
            resp = JSONResponse({"authenticated": True, "username": row["username"], "role": row["role"]})
            if app.state.security_mode == "HARDENED":
                resp.set_cookie(key="portal_session", value=f"uid-{row['username']}", httponly=True, samesite="lax")
            else:
                resp.set_cookie(key="portal_session", value=f"uid-{row['username']}")
            return resp
        return JSONResponse(status_code=401, content={"authenticated": False})

    @app.get("/search")
    async def search_students(
        q: str = Query(default=""),
        cls: str = Query(default=""),
        limit: int = Query(default=50, ge=1, le=500),
    ) -> JSONResponse:
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            like_q = f"%{q}%"
            where_sql = "(masv = ? OR fullname LIKE ? OR class_name LIKE ? OR note LIKE ?)"
            params: list[object] = [q, like_q, like_q, like_q]
            if cls.strip():
                where_sql += " AND class_name = ?"
                params.append(cls.strip())

            total_matched = int(
                conn.execute(f"SELECT COUNT(*) FROM students WHERE {where_sql}", params).fetchone()[0]
            )
            rows = [
                dict(r)
                for r in conn.execute(
                    f"SELECT masv, fullname, class_name, gpa, note FROM students WHERE {where_sql} LIMIT ?",
                    [*params, limit],
                ).fetchall()
            ]
        finally:
            conn.close()
        return JSONResponse({"query": q, "cls": cls, "count": len(rows), "total_matched": total_matched, "students": rows})

    @app.get("/grades")
    async def get_grades(masv: str = Query(default="SV001")) -> JSONResponse:
        conn = sqlite3.connect(resolved_db)
        conn.row_factory = sqlite3.Row
        try:
            if app.state.security_mode == "VULNERABLE":
                sql = f"SELECT masv, fullname, class_name, gpa FROM students WHERE masv = '{masv}'"
                try:
                    rows = [dict(r) for r in conn.execute(sql).fetchall()]
                except sqlite3.Error as exc:
                    return JSONResponse(status_code=500, content={"error": f"SQL syntax error: {exc}"})
            else:
                rows = [
                    dict(r)
                    for r in conn.execute(
                        "SELECT masv, fullname, class_name, gpa FROM students WHERE masv = ?",
                        (masv,),
                    ).fetchall()
                ]
        finally:
            conn.close()
        return JSONResponse({"query": masv, "count": len(rows), "students": rows})

    @app.post("/comments", response_class=HTMLResponse)
    @app.get("/comments", response_class=HTMLResponse)
    async def comments_endpoint(author: str = Query(default="Sinh vien"), msg: str = Query(default="")) -> HTMLResponse:
        if not msg:
            return HTMLResponse("<div>Binh luan mon hoc: an toan &amp; sach</div>")
        if app.state.security_mode == "HARDENED":
            return HTMLResponse(f"<div><b>{html.escape(author)}</b>: {html.escape(msg)}</div>")
        return HTMLResponse(f"<div><b>{author}</b>: {msg}</div>")

    @app.get("/download", response_class=PlainTextResponse)
    async def download_file(file: str = Query(default="tailieu.pdf")) -> PlainTextResponse:
        if app.state.security_mode == "HARDENED":
            candidate = (resolved_docs / file).resolve()
            if resolved_docs.resolve() not in candidate.parents or not candidate.is_file():
                return PlainTextResponse("400 Invalid file path (sandboxed)", status_code=400)
            return PlainTextResponse(candidate.read_text(encoding="utf-8", errors="replace"))

        candidate = resolved_docs / file
        if not candidate.exists() or not candidate.is_file():
            return PlainTextResponse("File not found", status_code=404)
        return PlainTextResponse(candidate.read_text(encoding="utf-8", errors="replace"))

    return app


if __name__ == "__main__":
    target_app = create_target_app()
    uvicorn.run(target_app, host="0.0.0.0", port=int(os.getenv("PORT", "8000")), log_level="warning")
