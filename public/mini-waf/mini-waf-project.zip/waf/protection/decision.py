"""
decision.py - Structured Security Decisions & Active Defense Coordinator.
Owned by Quyết (protection/rate_limit.py, blacklist.py, decision.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from waf.protection.blacklist import AutoBanManager, BanRecord
from waf.protection.client_ip import resolve_client_ip
from waf.protection.rate_limit import FixedWindowLimiter, RateLimitResult, SlidingWindowLimiter


@dataclass
class InspectionDecision:
    action: str  # ALLOW | LOG | BLOCK | CHALLENGE
    rule_id: str
    rule_ids: list[str]
    attack_type: str
    severity: str
    confidence: float
    anomaly_score: int
    matched_location: str
    matched_excerpt: str
    reason: str
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class PreCheckOutcome:
    allowed: bool
    client_ip: str
    status_code: int
    action: str  # ALLOWED | BANNED | RATE_LIMITED
    retry_after_sec: int
    reason: str


class ActiveDefenseManager:
    """Coordinates trusted IP extraction (anti-XFF spoofing), Rate Limiting, and Auto-Ban."""

    def __init__(
        self,
        rate_algo: str = "sliding",
        max_requests: int = 30,
        window_sec: int = 10,
        violation_threshold: int = 3,
        violation_window_sec: int = 60,
        ban_ttl_sec: int = 300,
        trusted_proxies: tuple[str, ...] = ("127.0.0.1", "::1"),
    ) -> None:
        self.trusted_proxies = trusted_proxies
        self.rate_algo = rate_algo if rate_algo in ("fixed", "sliding") else "sliding"
        self.enabled = True
        self._fixed = FixedWindowLimiter(max_requests=max_requests, window_sec=window_sec)
        self._sliding = SlidingWindowLimiter(max_requests=max_requests, window_sec=window_sec)
        self.autoban = AutoBanManager(
            violation_threshold=violation_threshold,
            violation_window_sec=violation_window_sec,
            ban_ttl_sec=ban_ttl_sec,
        )

    def set_algorithm(self, algo: str) -> str:
        if algo in ("fixed", "sliding"):
            self.rate_algo = algo
        return self.rate_algo

    def resolve_ip(self, peer_ip: str, x_forwarded_for: str | None = None) -> str:
        return resolve_client_ip(
            peer_ip=peer_ip,
            x_forwarded_for=x_forwarded_for,
            trusted_proxies=self.trusted_proxies,
        )

    def pre_check(self, peer_ip: str, x_forwarded_for: str | None = None) -> PreCheckOutcome:
        client_ip = self.resolve_ip(peer_ip, x_forwarded_for)
        if not self.enabled:
            return PreCheckOutcome(
                allowed=True,
                client_ip=client_ip,
                status_code=200,
                action="ALLOWED",
                retry_after_sec=0,
                reason="Active defense bypass enabled for latency benchmarking.",
            )

        ban_rec = self.autoban.is_banned(client_ip)
        if ban_rec is not None:
            return PreCheckOutcome(
                allowed=False,
                client_ip=client_ip,
                status_code=403,
                action="BANNED",
                retry_after_sec=0,
                reason=ban_rec.reason,
            )

        limiter = self._sliding if self.rate_algo == "sliding" else self._fixed
        rl: RateLimitResult = limiter.check(client_ip)
        if not rl.allowed:
            return PreCheckOutcome(
                allowed=False,
                client_ip=client_ip,
                status_code=429,
                action="RATE_LIMITED",
                retry_after_sec=rl.retry_after_sec,
                reason=f"Rate limit exceeded ({rl.algorithm} window: >{rl.limit}/{rl.window_sec}s)",
            )

        return PreCheckOutcome(
            allowed=True,
            client_ip=client_ip,
            status_code=200,
            action="ALLOWED",
            retry_after_sec=0,
            reason="Active defense passed.",
        )

    def on_waf_block(self, client_ip: str, rule_id: str) -> BanRecord | None:
        if not self.enabled:
            return None
        return self.autoban.record_violation(client_ip=client_ip, rule_id=rule_id)
