"""
defense.py - Unified Active Defense Coordinator & HTTP Response Header Hardening.
Coordinates Client IP extraction, O(1) Blacklist check, Rate Limiting, Auto-Ban escalation,
and HTTP Response Header / Set-Cookie / Error Scrubbing.
"""

from __future__ import annotations

from dataclasses import dataclass

from waf.protection.blacklist import AutoBanManager, BanRecord
from waf.protection.client_ip import resolve_client_ip
from waf.protection.rate_limit import FixedWindowLimiter, RateLimitResult, SlidingWindowLimiter


@dataclass(frozen=True)
class PreCheckOutcome:
    allowed: bool
    client_ip: str
    status_code: int
    action: str  # ALLOWED | BANNED | RATE_LIMITED
    retry_after_sec: int
    reason: str


class ActiveDefenseManager:
    """Coordinates anti-spoofing, rate limiting, and auto-ban enforcement."""

    def __init__(
        self,
        rate_algo: str = "sliding",
        max_requests: int = 30,
        window_sec: int = 10,
        violation_threshold: int = 3,
        violation_window_sec: int = 60,
        ban_ttl_sec: int = 300,
        trusted_proxies: tuple[str, ...] = ("127.0.0.1", "::1"),
    ) -> None:
        self.trusted_proxies = trusted_proxies
        self.rate_algo = rate_algo if rate_algo in ("fixed", "sliding") else "sliding"
        self.enabled = True
        self._fixed = FixedWindowLimiter(max_requests=max_requests, window_sec=window_sec)
        self._sliding = SlidingWindowLimiter(max_requests=max_requests, window_sec=window_sec)
        self.autoban = AutoBanManager(
            violation_threshold=violation_threshold,
            violation_window_sec=violation_window_sec,
            ban_ttl_sec=ban_ttl_sec,
        )

    def set_algorithm(self, algo: str) -> str:
        if algo in ("fixed", "sliding"):
            self.rate_algo = algo
        return self.rate_algo

    def resolve_ip(self, peer_ip: str, x_forwarded_for: str | None = None) -> str:
        return resolve_client_ip(
            peer_ip=peer_ip,
            x_forwarded_for=x_forwarded_for,
            trusted_proxies=self.trusted_proxies,
        )

    def pre_check(self, peer_ip: str, x_forwarded_for: str | None = None) -> PreCheckOutcome:
        client_ip = self.resolve_ip(peer_ip, x_forwarded_for)
        if not self.enabled:
            return PreCheckOutcome(
                allowed=True,
                client_ip=client_ip,
                status_code=200,
                action="ALLOWED",
                retry_after_sec=0,
                reason="Active defense bypass enabled for latency benchmarking.",
            )

        ban_rec = self.autoban.is_banned(client_ip)
        if ban_rec is not None:
            return PreCheckOutcome(
                allowed=False,
                client_ip=client_ip,
                status_code=403,
                action="BANNED",
                retry_after_sec=0,
                reason=ban_rec.reason,
            )

        limiter = self._sliding if self.rate_algo == "sliding" else self._fixed
        rl: RateLimitResult = limiter.check(client_ip)
        if not rl.allowed:
            return PreCheckOutcome(
                allowed=False,
                client_ip=client_ip,
                status_code=429,
                action="RATE_LIMITED",
                retry_after_sec=rl.retry_after_sec,
                reason=f"Rate limit exceeded ({rl.algorithm} window: >{rl.limit}/{rl.window_sec}s)",
            )

        return PreCheckOutcome(
            allowed=True,
            client_ip=client_ip,
            status_code=200,
            action="ALLOWED",
            retry_after_sec=0,
            reason="Active defense passed.",
        )

    def on_waf_block(self, client_ip: str, rule_id: str) -> BanRecord | None:
        if not self.enabled:
            return None
        return self.autoban.record_violation(client_ip=client_ip, rule_id=rule_id)


def harden_response_headers(raw_headers: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """
    Virtual Patching for outgoing HTTP Response headers:
      - Strips Server, X-Powered-By, X-AspNet-Version server fingerprinting headers
      - Appends HttpOnly; SameSite=Lax to Set-Cookie values missing them
      - Enforces X-Content-Type-Options, X-Frame-Options, Referrer-Policy, and basic CSP
    """
    strip_names = {"server", "x-powered-by", "x-aspnet-version", "content-length", "transfer-encoding"}
    out: list[tuple[str, str]] = []
    seen_lower: set[str] = set()

    for name, value in raw_headers:
        low = name.lower()
        if low in strip_names:
            continue
        if low == "set-cookie":
            low_val = value.lower()
            parts = [value]
            if "httponly" not in low_val:
                parts.append("HttpOnly")
            if "samesite=" not in low_val:
                parts.append("SameSite=Lax")
            out.append((name, "; ".join(parts)))
            continue
        seen_lower.add(low)
        out.append((name, value))

    required_defaults = [
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "no-referrer"),
        ("X-WAF-Protected-By", "Mini-WAF-v2"),
    ]
    for name, default_val in required_defaults:
        if name.lower() not in seen_lower:
            out.append((name, default_val))

    return out
