"""
defense.py - Response Header Hardening & Re-exports for Quyết's Active Defense package.
"""

from __future__ import annotations

from waf.protection.decision import ActiveDefenseManager, InspectionDecision, PreCheckOutcome


def harden_response_headers(raw_headers: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """
    Virtual Patching for outgoing HTTP Response headers:
      - Strips Server, X-Powered-By, X-AspNet-Version fingerprinting headers
      - Appends HttpOnly; SameSite=Lax to Set-Cookie values missing them
      - Enforces X-Content-Type-Options, X-Frame-Options, Referrer-Policy
    """
    strip_names = {"server", "x-powered-by", "x-aspnet-version", "content-length", "transfer-encoding"}
    out: list[tuple[str, str]] = []
    seen_lower: set[str] = set()

    for name, value in raw_headers:
        low = name.lower()
        if low in strip_names:
            continue
        if low == "set-cookie":
            low_val = value.lower()
            parts = [value]
            if "httponly" not in low_val:
                parts.append("HttpOnly")
            if "samesite=" not in low_val:
                parts.append("SameSite=Lax")
            out.append((name, "; ".join(parts)))
            continue
        seen_lower.add(low)
        out.append((name, value))

    required_defaults = [
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "no-referrer"),
        ("X-WAF-Protected-By", "Mini-WAF-v2"),
    ]
    for name, default_val in required_defaults:
        if name.lower() not in seen_lower:
            out.append((name, default_val))

    return out


__all__ = [
    "ActiveDefenseManager",
    "InspectionDecision",
    "PreCheckOutcome",
    "harden_response_headers",
]
