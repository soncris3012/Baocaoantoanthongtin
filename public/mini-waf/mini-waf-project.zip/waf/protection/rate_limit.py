"""
rate_limit.py - Rate Limiting Algorithms: Fixed Window vs Sliding Window (collections.deque).
Allows live hot-switching and boundary-burst demonstration as required by architecture spec.
"""

from __future__ import annotations

import math
import time
from collections import defaultdict, deque
from dataclasses import dataclass


@dataclass(frozen=True)
class RateLimitResult:
    allowed: bool
    algorithm: str
    limit: int
    window_sec: int
    current_count: int
    retry_after_sec: int


class FixedWindowLimiter:
    """Counts requests inside aligned fixed time buckets [floor(t / window)]."""

    def __init__(self, max_requests: int = 30, window_sec: int = 10) -> None:
        self.max_requests = max_requests
        self.window_sec = max(1, window_sec)
        self._buckets: dict[str, tuple[int, int]] = {}

    def check(self, client_ip: str, now: float | None = None) -> RateLimitResult:
        t = time.monotonic() if now is None else now
        bucket_id = int(t // self.window_sec)
        prev_bucket, count = self._buckets.get(client_ip, (bucket_id, 0))
        if prev_bucket != bucket_id:
            count = 0

        next_count = count + 1
        bucket_end = (bucket_id + 1) * self.window_sec
        retry_after = max(1, math.ceil(bucket_end - t))

        if next_count > self.max_requests:
            self._buckets[client_ip] = (bucket_id, count)
            return RateLimitResult(
                allowed=False,
                algorithm="fixed",
                limit=self.max_requests,
                window_sec=self.window_sec,
                current_count=count,
                retry_after_sec=retry_after,
            )

        self._buckets[client_ip] = (bucket_id, next_count)
        return RateLimitResult(
            allowed=True,
            algorithm="fixed",
            limit=self.max_requests,
            window_sec=self.window_sec,
            current_count=next_count,
            retry_after_sec=0,
        )

    def reset(self) -> None:
        self._buckets.clear()


class SlidingWindowLimiter:
    """
    Rolling timestamp queue per IP using collections.deque.
    Eliminates the 2x burst leak across adjacent Fixed Window boundaries.
    """

    def __init__(self, max_requests: int = 30, window_sec: int = 10) -> None:
        self.max_requests = max_requests
        self.window_sec = max(1, window_sec)
        self._windows: dict[str, deque[float]] = defaultdict(deque)

    def check(self, client_ip: str, now: float | None = None) -> RateLimitResult:
        t = time.monotonic() if now is None else now
        q = self._windows[client_ip]
        cutoff = t - self.window_sec

        while q and q[0] <= cutoff:
            q.popleft()

        if len(q) >= self.max_requests:
            oldest = q[0]
            retry_after = max(1, math.ceil((oldest + self.window_sec) - t))
            return RateLimitResult(
                allowed=False,
                algorithm="sliding",
                limit=self.max_requests,
                window_sec=self.window_sec,
                current_count=len(q),
                retry_after_sec=retry_after,
            )

        q.append(t)
        return RateLimitResult(
            allowed=True,
            algorithm="sliding",
            limit=self.max_requests,
            window_sec=self.window_sec,
            current_count=len(q),
            retry_after_sec=0,
        )

    def reset(self) -> None:
        self._windows.clear()
