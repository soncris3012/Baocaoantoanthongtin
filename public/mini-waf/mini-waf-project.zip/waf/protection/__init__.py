"""Active defense package: anti-spoofing IP identification, Rate Limiting, Auto-Ban, header hardening."""
