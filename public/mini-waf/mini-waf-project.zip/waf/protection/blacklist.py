"""
blacklist.py - O(1) RAM Auto-Ban Blacklist with Temporary TTL.
Never applies permanent IP bans on single detections; automatically expires entries and supports manual Unban.
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone


UTC_PLUS_7 = timezone(timedelta(hours=7))


@dataclass
class BanRecord:
    ip: str
    reason: str
    banned_at_iso: str
    expires_at_iso: str
    expires_at_epoch: float


class AutoBanManager:
    """Tracks BLOCKED violations inside a rolling window and triggers temporary TTL bans."""

    def __init__(
        self,
        violation_threshold: int = 3,
        violation_window_sec: int = 60,
        ban_ttl_sec: int = 300,
    ) -> None:
        self.violation_threshold = max(2, violation_threshold)
        self.violation_window_sec = max(10, violation_window_sec)
        self.ban_ttl_sec = max(10, ban_ttl_sec)
        self._violations: dict[str, deque[float]] = defaultdict(deque)
        self._bans: dict[str, BanRecord] = {}

    def is_banned(self, client_ip: str, now_epoch: float | None = None) -> BanRecord | None:
        """O(1) dictionary check with automatic TTL expiration cleanup."""
        rec = self._bans.get(client_ip)
        if rec is None:
            return None
        now = time.time() if now_epoch is None else now_epoch
        if now >= rec.expires_at_epoch:
            del self._bans[client_ip]
            return None
        return rec

    def record_violation(
        self,
        client_ip: str,
        rule_id: str,
        now_epoch: float | None = None,
    ) -> BanRecord | None:
        """Record a BLOCKED offense; return BanRecord if threshold crossed within rolling window."""
        now = time.time() if now_epoch is None else now_epoch
        q = self._violations[client_ip]
        cutoff = now - self.violation_window_sec
        while q and q[0] <= cutoff:
            q.popleft()
        q.append(now)

        if len(q) >= self.violation_threshold:
            q.clear()
            banned_dt = datetime.fromtimestamp(now, tz=UTC_PLUS_7)
            expires_dt = datetime.fromtimestamp(now + self.ban_ttl_sec, tz=UTC_PLUS_7)
            rec = BanRecord(
                ip=client_ip,
                reason=f"Auto-Ban: >= {self.violation_threshold} WAF BLOCK events within {self.violation_window_sec}s (last: {rule_id})",
                banned_at_iso=banned_dt.isoformat(timespec="seconds"),
                expires_at_iso=expires_dt.isoformat(timespec="seconds"),
                expires_at_epoch=now + self.ban_ttl_sec,
            )
            self._bans[client_ip] = rec
            return rec
        return None

    def unban(self, client_ip: str) -> bool:
        existed = client_ip in self._bans
        self._bans.pop(client_ip, None)
        self._violations.pop(client_ip, None)
        return existed

    def list_active(self, now_epoch: float | None = None) -> list[dict[str, object]]:
        now = time.time() if now_epoch is None else now_epoch
        expired = [ip for ip, rec in self._bans.items() if now >= rec.expires_at_epoch]
        for ip in expired:
            del self._bans[ip]
        return [
            {
                "ip": rec.ip,
                "reason": rec.reason,
                "banned_at": rec.banned_at_iso,
                "expires_at": rec.expires_at_iso,
                "remaining_sec": max(0, int(rec.expires_at_epoch - now)),
            }
            for rec in sorted(self._bans.values(), key=lambda r: r.expires_at_epoch, reverse=True)
        ]

    def reset(self) -> None:
        self._bans.clear()
        self._violations.clear()
