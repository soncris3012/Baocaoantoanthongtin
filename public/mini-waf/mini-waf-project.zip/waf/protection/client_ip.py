"""
client_ip.py - Trusted Proxy-Aware Client IP Resolution.
Prevents X-Forwarded-For spoofing: headers supplied by untrusted peers are ignored.
"""

from __future__ import annotations

from ipaddress import ip_address, ip_network


def resolve_client_ip(
    peer_ip: str,
    x_forwarded_for: str | None = None,
    trusted_proxies: tuple[str, ...] = ("127.0.0.1", "::1"),
) -> str:
    """
    Return the authoritative client IP.
    Only trusts X-Forwarded-For when direct TCP peer is in trusted_proxies.
    """
    clean_peer = (peer_ip or "127.0.0.1").strip()
    if not x_forwarded_for or not x_forwarded_for.strip():
        return clean_peer

    is_trusted = False
    try:
        peer_obj = ip_address(clean_peer)
        for item in trusted_proxies:
            entry = item.strip()
            if not entry:
                continue
            if "/" in entry:
                if peer_obj in ip_network(entry, strict=False):
                    is_trusted = True
                    break
            elif peer_obj == ip_address(entry):
                is_trusted = True
                break
    except ValueError:
        is_trusted = clean_peer in trusted_proxies

    if not is_trusted:
        return clean_peer

    # Take the leftmost non-empty forwarded IP supplied by our trusted reverse proxy chain
    hops = [part.strip() for part in x_forwarded_for.split(",") if part.strip()]
    if not hops:
        return clean_peer
    candidate = hops[0]
    try:
        ip_address(candidate)
        return candidate
    except ValueError:
        return clean_peer
