"""
telegram_alert.py - Non-Blocking Redacted Security Alert Notifier.
Uses asyncio.create_task so external internet latency never delays Reverse Proxy forwarding.
Strictly omits raw exploit payloads, cookies, passwords, and student PII from Telegram messages.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timedelta, timezone

import httpx


UTC_PLUS_7 = timezone(timedelta(hours=7))


def format_redacted_alert(
    attack_type: str,
    client_ip: str,
    rule_ids: list[str] | str,
    action: str,
    timestamp_iso: str | None = None,
) -> str:
    rules_str = ",".join(rule_ids) if isinstance(rule_ids, list) else (rule_ids or "NONE")
    ts = timestamp_iso or datetime.now(tz=UTC_PLUS_7).strftime("%H:%M:%S %d/%m/%Y")
    return (
        "[Mini-WAF] Phat hien su kien bao mat\n"
        f"Loai: {attack_type}\n"
        f"IP: {client_ip}\n"
        f"Thoi gian: {ts}\n"
        f"Quy tac: {rules_str}\n"
        f"Hanh dong: {action}"
    )


async def _send_telegram_async(message: str, bot_token: str, chat_id: str) -> None:
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=3.5) as client:
            await client.post(url, json={"chat_id": chat_id, "text": message})
    except Exception:
        # Never crash reverse proxy path if Telegram API is offline or unreachable in air-gapped labs
        return


def trigger_telegram_alert(
    attack_type: str,
    client_ip: str,
    rule_ids: list[str] | str,
    action: str,
    sent_log: list[str] | None = None,
) -> None:
    """Dispatch redacted Telegram alert asynchronously on background event loop."""
    msg = format_redacted_alert(attack_type, client_ip, rule_ids, action)
    if sent_log is not None:
        sent_log.append(msg)

    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not bot_token or not chat_id:
        return

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_send_telegram_async(msg, bot_token, chat_id))
    except RuntimeError:
        return
