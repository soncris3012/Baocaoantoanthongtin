"""Monitoring package: Log sanitization, Admin Dashboard (:8888), and redacted Telegram alerting."""
