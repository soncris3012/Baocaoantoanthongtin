"""
logger.py - Privacy & Security-Preserving Log Sanitization (Masking).
Never stores plaintext cookies, passwords, Authorization Bearer tokens, or sensitive student PII in SQLite.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

from waf.database.models import SecurityEventRecord


UTC_PLUS_7 = timezone(timedelta(hours=7))

SECRET_KV_RE = re.compile(
    r"(?i)\b(password|passwd|pwd|token|secret|authorization|cookie|phpsessid|session_id)\s*([=:])\s*([^&\s,;\"']+)"
)
BEARER_RE = re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9\-_.~+/=]+")
JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_.-]+\b")


def sanitize_snippet(raw_text: str, max_len: int = 250) -> str:
    """Mask secret/credential fields and clip log snippet to <= 250 characters."""
    if not raw_text:
        return ""
    masked = BEARER_RE.sub(lambda m: f"{m.group(1)} ***MASKED***", raw_text)
    masked = JWT_RE.sub("***JWT_MASKED***", masked)
    masked = SECRET_KV_RE.sub(lambda m: f"{m.group(1)}{m.group(2)}***MASKED***", masked)
    masked = re.sub(r"[\r\n\t]+", " ", masked).strip()
    if len(masked) > max_len:
        return masked[: max_len - 3] + "..."
    return masked


def build_sanitized_event(
    client_ip: str,
    method: str,
    path: str,
    raw_snippet: str,
    rule_ids: list[str],
    category: str,
    anomaly_score: int,
    action: str,
    latency_ms: float,
) -> SecurityEventRecord:
    return SecurityEventRecord(
        timestamp=datetime.now(tz=UTC_PLUS_7).isoformat(timespec="seconds"),
        client_ip=client_ip,
        method=method.upper(),
        path=sanitize_snippet(path, max_len=160),
        payload_snippet=sanitize_snippet(raw_snippet, max_len=250),
        rule_ids=",".join(rule_ids) if rule_ids else "NONE",
        category=category or "Normal",
        anomaly_score=anomaly_score,
        action=action,
        latency_ms=latency_ms,
    )
