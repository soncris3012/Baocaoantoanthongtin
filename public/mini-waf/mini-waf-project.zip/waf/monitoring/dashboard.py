"""
dashboard.py - Isolated Admin Dashboard & Control Plane API (Port 8888).
Never exposed on proxy port 8080; requires Admin Token or authenticated session cookie.
"""

from __future__ import annotations

import hmac
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from waf.proxy.forward import WafRuntime


TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"


class LoginPayload(BaseModel):
    password: str


class ModePayload(BaseModel):
    mode: str  # OFF | MONITOR | BLOCKING


class UnbanPayload(BaseModel):
    ip: str


class DefenseConfigPayload(BaseModel):
    rate_algo: str | None = None
    active_defense_enabled: bool | None = None


def _is_authorized(request: Request, runtime: WafRuntime) -> bool:
    header_tok = request.headers.get("x-admin-token", "")
    auth_hdr = request.headers.get("authorization", "")
    cookie_tok = request.cookies.get("miniwaf_admin", "")
    bearer = auth_hdr[7:].strip() if auth_hdr.lower().startswith("bearer ") else ""
    for cand in (header_tok, bearer, cookie_tok):
        if cand and hmac.compare_digest(cand, runtime.admin_token):
            return True
    return False


def create_admin_app(runtime: WafRuntime) -> FastAPI:
    """Create separate Admin Monitoring ASGI app for port 8888."""

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        await runtime.repo.init()
        yield

    app = FastAPI(title="Mini-WAF Admin Dashboard (:8888)", docs_url=None, redoc_url=None, lifespan=lifespan)
    templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
    app.state.runtime = runtime

    @app.get("/", response_class=HTMLResponse)
    @app.get("/dashboard", response_class=HTMLResponse)
    async def render_dashboard(request: Request) -> HTMLResponse:
        return templates.TemplateResponse(
            request=request,
            name="dashboard.html",
            context={"authenticated": _is_authorized(request, runtime)},
        )

    @app.post("/api/login")
    async def admin_login(body: LoginPayload) -> JSONResponse:
        if not hmac.compare_digest(body.password, runtime.admin_password):
            raise HTTPException(status_code=401, detail="Sai mật khẩu quản trị Mini-WAF")
        resp = JSONResponse({"ok": True})
        resp.set_cookie(
            key="miniwaf_admin",
            value=runtime.admin_token,
            httponly=True,
            samesite="lax",
            path="/",
        )
        return resp

    @app.post("/api/logout")
    async def admin_logout() -> JSONResponse:
        resp = JSONResponse({"ok": True})
        resp.delete_cookie("miniwaf_admin", path="/")
        return resp

    @app.get("/api/stats")
    async def get_stats(request: Request) -> JSONResponse:
        if not _is_authorized(request, runtime):
            raise HTTPException(status_code=401, detail="Admin authentication required")
        await runtime.repo.purge_expired_bans()
        stats = await runtime.repo.get_stats(limit_logs=40)
        banned_list = runtime.defense.autoban.list_active()
        stats["mode"] = runtime.mode
        stats["rate_algo"] = runtime.defense.rate_algo
        stats["active_defense_enabled"] = runtime.defense.enabled
        stats["banned_ips"] = banned_list
        stats["banned_count"] = len(banned_list)
        stats["telegram_alert_count"] = len(runtime.telegram_sent_log)
        stats["upstream_url"] = runtime.upstream_url
        return JSONResponse(stats)

    @app.post("/api/mode")
    async def set_mode(request: Request, body: ModePayload) -> JSONResponse:
        if not _is_authorized(request, runtime):
            raise HTTPException(status_code=401, detail="Admin authentication required")
        next_mode = body.mode.upper().strip()
        if next_mode not in ("OFF", "MONITOR", "BLOCKING"):
            raise HTTPException(status_code=400, detail="Mode must be OFF, MONITOR, or BLOCKING")
        runtime.mode = next_mode
        return JSONResponse({"ok": True, "mode": runtime.mode})

    @app.post("/api/unban")
    async def unban_ip(request: Request, body: UnbanPayload) -> JSONResponse:
        if not _is_authorized(request, runtime):
            raise HTTPException(status_code=401, detail="Admin authentication required")
        removed = runtime.defense.autoban.unban(body.ip.strip())
        await runtime.repo.remove_ban(body.ip.strip())
        return JSONResponse({"ok": True, "ip": body.ip.strip(), "removed": removed})

    @app.post("/api/defense-config")
    async def set_defense_config(request: Request, body: DefenseConfigPayload) -> JSONResponse:
        if not _is_authorized(request, runtime):
            raise HTTPException(status_code=401, detail="Admin authentication required")
        if body.rate_algo is not None:
            runtime.defense.set_algorithm(body.rate_algo)
        if body.active_defense_enabled is not None:
            runtime.defense.enabled = body.active_defense_enabled
        return JSONResponse(
            {
                "ok": True,
                "rate_algo": runtime.defense.rate_algo,
                "active_defense_enabled": runtime.defense.enabled,
            }
        )

    return app
