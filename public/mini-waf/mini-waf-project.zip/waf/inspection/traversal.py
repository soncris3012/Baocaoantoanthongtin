"""
traversal.py - Path Traversal (LFI) & Scanner Probe Endpoint Detector.
Owned by Hùng (inspection/traversal.py): catches directory escape (../, ....//),
null-byte truncation (%00), OS sensitive system paths, and sensitive scanner probe targets.
"""

from __future__ import annotations

import re

from waf.inspection.normalizer import NormalizedViews
from waf.inspection.sqli import RuleFinding


LFI_PATTERN = re.compile(
    r"(?:\.\./|\.\.\\|\x00|%00|/etc/passwd|/etc/shadow|/etc/hosts|/proc/self/|\\windows\\win\.ini|file://)",
    re.IGNORECASE,
)
SCANNER_UA_PATTERN = re.compile(
    r"\b(?:sqlmap|nikto|acunetix|masscan|hydra|nessus|gobuster|dirbuster|wfuzz|ffuf|havij)\b",
    re.IGNORECASE,
)
SENSITIVE_PATH_PATTERN = re.compile(
    r"(?:^/\.env$|^/\.git(?:/|$)|/wp-login\.php$|/phpmyadmin(?:/|$)|/actuator/env$|/cgi-bin/)",
    re.IGNORECASE,
)


def inspect_traversal(raw_value: str, views: NormalizedViews, weights_override: dict[str, int] | None = None) -> list[RuleFinding]:
    candidates = (views.spaced, views.collapsed, raw_value)
    if any(LFI_PATTERN.search(c) for c in candidates):
        w = int((weights_override or {}).get("LFI-01", 5))
        return [
            RuleFinding(
                rule_id="LFI-01",
                group="LFI",
                weight=w,
                severity="HIGH",
                reason=f"LFI-01 (Path Traversal & Sensitive System Files, +{w})",
            )
        ]
    return []


def inspect_scanner_signals(
    location: str,
    name: str,
    views: NormalizedViews,
    weights_override: dict[str, int] | None = None,
) -> list[RuleFinding]:
    findings: list[RuleFinding] = []
    weights = weights_override or {}
    if location == "header" and name == "user-agent":
        if SCANNER_UA_PATTERN.search(views.spaced):
            w = int(weights.get("SCN-01", 3))
            findings.append(
                RuleFinding(
                    rule_id="SCN-01",
                    group="Scanner",
                    weight=w,
                    severity="MEDIUM",
                    reason=f"SCN-01 (Automated Scanner User-Agent Signal, +{w})",
                )
            )
    if location == "path" and SENSITIVE_PATH_PATTERN.search(views.spaced):
        w = int(weights.get("SCN-02", 3))
        findings.append(
            RuleFinding(
                rule_id="SCN-02",
                group="Scanner",
                weight=w,
                severity="MEDIUM",
                reason=f"SCN-02 (Sensitive Hidden Probe Endpoint, +{w})",
            )
        )
    return findings
