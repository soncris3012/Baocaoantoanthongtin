"""
normalizer.py - Multi-Stage Anti-Evasion Normalization Pipeline.
Defeats double/triple URL encoding, HTML entities, Unicode fullwidth homoglyphs,
JSON \\uXXXX escapes, MySQL conditional comments (/*!50000...*/), and inline keyword splitting.
"""

from __future__ import annotations

import html
import re
import unicodedata
import urllib.parse
from dataclasses import dataclass


MAX_NORMALIZE_LEN = 4096


@dataclass(frozen=True)
class NormalizedViews:
    raw: str
    decoded: str
    spaced: str
    collapsed: str


def _decode_unicode_escapes(text: str) -> str:
    """Decode explicit \\uXXXX and \\xXX escapes safely without raising on partial sequences."""
    def _u_repl(match: re.Match[str]) -> str:
        return chr(int(match.group(1), 16))

    def _x_repl(match: re.Match[str]) -> str:
        return chr(int(match.group(1), 16))

    text = re.sub(r"\\u([0-9a-fA-F]{4})", _u_repl, text)
    text = re.sub(r"\\x([0-9a-fA-F]{2})", _x_repl, text)
    return text


def recursive_url_decode(raw: str, max_passes: int = 3) -> str:
    """Iteratively decode URL-encoded payloads (handles %2527 -> %27 -> ') while preserving null bytes."""
    current = raw[:MAX_NORMALIZE_LEN]
    for _ in range(max_passes):
        # Preserve explicit %00 before unquote/plus normalization if mixed with pluses
        next_val = urllib.parse.unquote_plus(current)
        if next_val == current:
            break
        current = next_val
    return current


def normalize_for_inspection(raw: str) -> NormalizedViews:
    """
    Produce dual canonical lowercase representations for pattern and lexer matching:
      - decoded: URL + HTML entity + Unicode NFKC decoded (case preserved for lexical tokens)
      - spaced: inline comments replaced with space (prevents SELECT/**/FROM -> SELECTFROM)
      - collapsed: inline comments stripped cleanly (catches UN/**/ION SEL/**/ECT)
    """
    clipped = (raw or "")[:MAX_NORMALIZE_LEN]
    url_decoded = recursive_url_decode(clipped, max_passes=3)
    unicode_unescaped = _decode_unicode_escapes(url_decoded)
    entity_decoded = html.unescape(unicode_unescaped)
    canonical = unicodedata.normalize("NFKC", entity_decoded)

    # First unwrap MySQL conditional execution comments /*!50000UNION*/ -> UNION
    cond_unwrapped = re.sub(
        r"/\*!\d*\s*(.*?)\s*\*/", r" \1 ", canonical, flags=re.DOTALL
    )
    cond_collapsed = re.sub(
        r"/\*!\d*\s*(.*?)\s*\*/", r"\1", canonical, flags=re.DOTALL
    )

    # Spaced view turns /**/ into whitespace; collapsed view strips /**/ between split letters
    spaced = re.sub(r"/\*.*?\*/", " ", cond_unwrapped, flags=re.DOTALL)
    collapsed = re.sub(r"/\*.*?\*/", "", cond_collapsed, flags=re.DOTALL)

    # Normalize control characters and redundant spaces
    spaced = re.sub(r"[\t\r\n]+", " ", spaced)
    spaced = re.sub(r"\s{2,}", " ", spaced).strip().lower()

    collapsed = re.sub(r"[\t\r\n]+", " ", collapsed)
    collapsed = re.sub(r"\s{2,}", " ", collapsed).strip().lower()

    # Path traversal normalization helper: collapse '....//' style double dots while keeping '../' detectable
    if "....//" in spaced:
        spaced = spaced.replace("....//", "../../")
    if "....\\\\" in spaced:
        spaced = spaced.replace("....\\\\", "..\\..\\")

    return NormalizedViews(
        raw=clipped,
        decoded=canonical,
        spaced=spaced,
        collapsed=collapsed,
    )
