"""Structured HTTP request extraction, anti-evasion normalization, and anomaly scoring."""
