"""
parser.py - HTTP Request Component Extraction with HTTP Parameter Pollution (HPP)
and nested JSON body awareness.
"""

from __future__ import annotations

import json
import re
import urllib.parse
from dataclasses import dataclass, field


HTML_ENTITY_PARAM_RE = re.compile(r"&(?:#\d{1,5}|#x[0-9a-fA-F]{1,4}|lt|gt|quot|apos);", re.IGNORECASE)


MAX_PARAM_LEN = 4096
MAX_BODY_BYTES = 65536


@dataclass(frozen=True)
class ExtractedSurface:
    location: str
    name: str
    value: str


@dataclass
class ParsedHttpRequest:
    method: str
    path: str
    raw_query: str
    query_items: list[tuple[str, str]]
    body_params: list[tuple[str, str]]
    headers: dict[str, str]
    surfaces: list[ExtractedSurface] = field(default_factory=list)


def _flatten_json(data: object, prefix: str = "", out: list[tuple[str, str]] | None = None) -> list[tuple[str, str]]:
    """Recursively flatten all JSON string/scalar values so nested payloads cannot hide."""
    if out is None:
        out = []
    if len(out) >= 128:
        return out
    if isinstance(data, dict):
        for k, v in data.items():
            key_str = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(k, str):
                out.append((f"{key_str}#key", k[:MAX_PARAM_LEN]))
            _flatten_json(v, key_str, out)
    elif isinstance(data, list):
        for idx, item in enumerate(data):
            _flatten_json(item, f"{prefix}[{idx}]", out)
    elif isinstance(data, (str, int, float, bool)):
        out.append((prefix or "json_body", str(data)[:MAX_PARAM_LEN]))
    return out


def extract_http_components(
    method: str,
    path: str,
    raw_query: str = "",
    raw_body: bytes = b"",
    headers: dict[str, str] | None = None,
) -> ParsedHttpRequest:
    """
    Extract Method, Path, all Query Params (preserving duplicate keys to catch HPP),
    Form/JSON Body parameters, and relevant HTTP Headers for downstream inspection.
    """
    hdrs = {k.lower(): v[:MAX_PARAM_LEN] for k, v in (headers or {}).items()}
    clipped_path = (path or "/")[:MAX_PARAM_LEN]
    clipped_query = (raw_query or "")[:MAX_PARAM_LEN]

    # Parse query keeping duplicate keys (anti HTTP Parameter Pollution bypass)
    # Also preserve unencoded HTML entities (e.g. ?msg=&lt;script&gt; or ?q=&#39; OR &#39;1&#39;=&#39;1)
    # where literal '&' inside an entity would otherwise falsely split query parameters.
    safe_query_for_split = HTML_ENTITY_PARAM_RE.sub(
        lambda m: "%26" + m.group(0)[1:], clipped_query
    )
    query_items: list[tuple[str, str]] = []
    if safe_query_for_split:
        for pair in safe_query_for_split.split("&"):
            if not pair:
                continue
            if "=" in pair:
                k, v = pair.split("=", 1)
            else:
                k, v = pair, ""
            query_items.append((k[:256], v[:MAX_PARAM_LEN]))

    body_params: list[tuple[str, str]] = []
    content_type = hdrs.get("content-type", "").lower()
    body_slice = raw_body[:MAX_BODY_BYTES]
    body_text = body_slice.decode("utf-8", errors="replace") if body_slice else ""

    if body_text.strip():
        if "application/json" in content_type or body_text.lstrip().startswith(("{", "[")):
            try:
                parsed_json = json.loads(body_text)
                body_params.extend(_flatten_json(parsed_json))
            except json.JSONDecodeError:
                body_params.append(("raw_json", body_text[:MAX_PARAM_LEN]))
        elif "application/x-www-form-urlencoded" in content_type or "=" in body_text:
            for pair in body_text.split("&"):
                if not pair:
                    continue
                if "=" in pair:
                    k, v = pair.split("=", 1)
                else:
                    k, v = pair, ""
                body_params.append((k[:256], v[:MAX_PARAM_LEN]))
        else:
            body_params.append(("raw_body", body_text[:MAX_BODY_BYTES]))

    surfaces: list[ExtractedSurface] = [
        ExtractedSurface(location="path", name="url_path", value=clipped_path)
    ]

    for k, v in query_items:
        surfaces.append(ExtractedSurface(location="query", name=k, value=v))
        decoded_k = urllib.parse.unquote_plus(k)
        if decoded_k != k:
            surfaces.append(ExtractedSurface(location="query_key", name=k, value=decoded_k))

    # HPP combined view: Detect multi-parameter split SQLi (?id=1&id=' OR 1=1 -> single combined token)
    grouped_vals: dict[str, list[str]] = {}
    for k, v in query_items:
        grouped_vals.setdefault(k, []).append(v)
    for k, vals in grouped_vals.items():
        if len(vals) > 1:
            surfaces.append(
                ExtractedSurface(
                    location="query_hpp",
                    name=f"{k}[]",
                    value=" ".join(vals)[:MAX_PARAM_LEN],
                )
            )

    for k, v in body_params:
        surfaces.append(ExtractedSurface(location="body", name=k, value=v))

    for hname in ("user-agent", "referer", "cookie"):
        if hname in hdrs and hdrs[hname]:
            surfaces.append(ExtractedSurface(location="header", name=hname, value=hdrs[hname]))

    return ParsedHttpRequest(
        method=(method or "GET").upper(),
        path=clipped_path,
        raw_query=clipped_query,
        query_items=query_items,
        body_params=body_params,
        headers=hdrs,
        surfaces=surfaces,
    )
