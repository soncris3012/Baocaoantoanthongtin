"""
sqli.py - SQL Injection Detector & Context-Aware SQL Lexical Analyzer.
Owned by Hùng (inspection/sqli.py): detects SQL delimiters, boolean tautologies,
UNION/SELECT/information_schema/sqlite_master dumps, blind timing attacks, and
structural SQL grammar while allowing benign apostrophes such as O'Brien / D'Angelo.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from waf.inspection.normalizer import NormalizedViews, normalize_for_inspection


SQL_KEYWORDS = frozenset(
    {
        "SELECT",
        "UNION",
        "ALL",
        "FROM",
        "WHERE",
        "AND",
        "OR",
        "XOR",
        "ORDER",
        "BY",
        "GROUP",
        "HAVING",
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "ALTER",
        "SLEEP",
        "BENCHMARK",
        "WAITFOR",
        "DELAY",
        "CONCAT",
        "GROUP_CONCAT",
        "SUBSTRING",
        "SUBSTR",
        "ASCII",
        "CHAR",
        "INFORMATION_SCHEMA",
        "SQLITE_MASTER",
        "OUTFILE",
        "DUMPFILE",
        "LOAD_FILE",
        "INTO",
        "NULL",
        "EXTRACTVALUE",
        "UPDATEXML",
        "TRUE",
        "FALSE",
    }
)


@dataclass(frozen=True)
class SqlToken:
    kind: str  # n=number, s=string, o=operator/delimiter, k=keyword, w=word/ident, c=comment
    lexeme: str


@dataclass(frozen=True)
class RuleFinding:
    rule_id: str
    group: str
    weight: int
    severity: str
    reason: str


SQL_REGEX_RULES: tuple[tuple[str, re.Pattern[str], int, str, str], ...] = (
    (
        "SQL-01",
        re.compile(r"(?:'|\"|\s--(?:\s|$)|#)", re.IGNORECASE),
        2,
        "LOW",
        "SQL Quote or Inline Comment Signal",
    ),
    (
        "SQL-02",
        re.compile(
            r"(?:(?:'|\")\s*(?:or|and|xor)\s+(?:['\"]?[a-z0-9_]+['\"]?\s*=\s*['\"]?[a-z0-9_]+['\"]?|true\b))|(?:\b(?:or|and|xor)\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+['\"]?)|(?:\bor\s+'[^']{1,32}'\s*=\s*'[^']{1,32}')",
            re.IGNORECASE,
        ),
        5,
        "HIGH",
        "SQL Tautology & Boolean Logic",
    ),
    (
        "SQL-03",
        re.compile(
            r"(?:\bunion(?:\s+all)?\s+(?:select\b|\(\s*select\b))|(?:\b(?:information_schema|sqlite_master)\b)|(?:\binto\s+(?:outfile|dumpfile)\b)|(?:\bload_file\s*\()",
            re.IGNORECASE,
        ),
        6,
        "CRITICAL",
        "SQL UNION SELECT & Metadata Enumeration",
    ),
    (
        "SQL-04",
        re.compile(
            r"(?:\b(?:sleep|benchmark|pg_sleep|randomblob)\s*\()|(?:\bwaitfor\s+delay\b)|(?:;\s*(?:drop\s+table|delete\s+from|insert\s+into|alter\s+table)\b)",
            re.IGNORECASE,
        ),
        6,
        "HIGH",
        "Time-Based Blind SQLi & Stacked DDL",
    ),
)


def tokenize_sql(text: str) -> list[SqlToken]:
    """Scan a SQL-normalized text fragment into lexical tokens."""
    tokens: list[SqlToken] = []
    i = 0
    n = len(text)

    while i < n and len(tokens) < 96:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch == "#" or text[i : i + 2] == "--":
            tokens.append(SqlToken("c", text[i : i + 32]))
            break
        if ch in ("'", '"'):
            quote = ch
            j = i + 1
            while j < n and text[j] != quote:
                j += 1
            if j < n:
                tokens.append(SqlToken("s", text[i : j + 1]))
                i = j + 1
            else:
                tokens.append(SqlToken("o", quote))
                i += 1
            continue
        if text[i : i + 2] in ("<=", ">=", "<>", "!=", "||", "&&"):
            tokens.append(SqlToken("o", text[i : i + 2]))
            i += 2
            continue
        if ch in ("=", "<", ">", "(", ")", ",", ";", "+", "-", "*", "/"):
            tokens.append(SqlToken("o", ch))
            i += 1
            continue
        if ch.isdigit():
            m = re.match(r"0x[0-9a-fA-F]+|\d+(?:\.\d+)?", text[i:])
            if m:
                lex = m.group(0)
                tokens.append(SqlToken("n", lex))
                i += len(lex)
                continue
        if ch.isalpha() or ch in ("_", "@", "."):
            m = re.match(r"[A-Za-z_@.][A-Za-z0-9_@.$]*", text[i:])
            if m:
                lex = m.group(0)
                kind = "k" if lex.upper() in SQL_KEYWORDS else "w"
                tokens.append(SqlToken(kind, lex))
                i += len(lex)
                continue
        tokens.append(SqlToken("o", ch))
        i += 1

    return tokens


def analyze_sql_grammar(raw_value: str) -> tuple[bool, str, str]:
    """Distinguish structural SQLi grammar from benign apostrophes (O'Brien, D'Angelo)."""
    views = normalize_for_inspection(raw_value)
    fingerprint = ""
    for variant in (views.spaced, views.collapsed):
        tokens = tokenize_sql(variant)
        if not tokens:
            continue
        fingerprint = "".join(t.kind for t in tokens[:8])
        kws = [t.lexeme.upper() for t in tokens if t.kind == "k"]
        ops = [t.lexeme for t in tokens if t.kind == "o"]
        has_comment = any(t.kind == "c" for t in tokens)
        has_quote = ("'" in ops or '"' in ops or any(t.kind == "s" for t in tokens))

        if "UNION" in kws and "SELECT" in kws:
            return True, fingerprint, "Detected structural UNION + SELECT token sequence"
        if has_quote and any(k in ("OR", "AND", "XOR") for k in kws):
            if "=" in ops or has_comment or "TRUE" in kws:
                return True, fingerprint, "Detected quote breakout with boolean logic comparator"
        funcs = {
            "SLEEP",
            "BENCHMARK",
            "WAITFOR",
            "ASCII",
            "SUBSTRING",
            "SUBSTR",
            "EXTRACTVALUE",
            "UPDATEXML",
            "LOAD_FILE",
            "GROUP_CONCAT",
        }
        if any(k in funcs for k in kws) and "(" in ops:
            return True, fingerprint, "Detected SQL timing/blind function call"
        if any(k in ("INFORMATION_SCHEMA", "SQLITE_MASTER", "OUTFILE", "DUMPFILE") for k in kws):
            return True, fingerprint, "Detected SQL metadata schema or OUTFILE keyword"
        for idx, tok in enumerate(tokens[:-1]):
            if tok.lexeme == ";" and tokens[idx + 1].kind == "k":
                if tokens[idx + 1].lexeme.upper() in ("SELECT", "DROP", "DELETE", "INSERT", "UPDATE", "ALTER"):
                    return True, fingerprint, "Detected stacked SQL statement after semicolon"
    return False, fingerprint, ""


def inspect_sqli(raw_value: str, views: NormalizedViews, weights_override: dict[str, int] | None = None) -> list[RuleFinding]:
    """Evaluate normalized input against regex rules SQL-01..SQL-04 and SQL Lexical Tokenizer (SQL-05)."""
    findings: list[RuleFinding] = []
    weights = weights_override or {}
    candidates = (views.spaced, views.collapsed, raw_value)

    for rule_id, pattern, default_w, severity, title in SQL_REGEX_RULES:
        if any(pattern.search(c) for c in candidates):
            w = int(weights.get(rule_id, default_w))
            findings.append(
                RuleFinding(
                    rule_id=rule_id,
                    group="SQLi",
                    weight=w,
                    severity=severity,
                    reason=f"{rule_id} ({title}, +{w})",
                )
            )

    suspicious_lex, fp, lex_reason = analyze_sql_grammar(raw_value)
    if suspicious_lex:
        w = int(weights.get("SQL-05", 6))
        findings.append(
            RuleFinding(
                rule_id="SQL-05",
                group="SQLi",
                weight=w,
                severity="HIGH",
                reason=f"SQL-05 ({lex_reason} [{fp}], +{w})",
            )
        )
    return findings
