"""
engine.py - Anomaly Scoring & Structured Decision Engine.
Combines HTTP parsing, multi-pass anti-evasion normalization, linear regex rules,
and SQL Lexical Grammar analysis to return structured ALLOW/LOG/BLOCK decisions.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from waf.inspection.normalizer import normalize_for_inspection
from waf.inspection.parser import ParsedHttpRequest, extract_http_components
from waf.inspection.sql_lexer import analyze_sql_grammar


DEFAULT_RULES_PATH = Path(__file__).resolve().parent.parent / "rules.json"


@dataclass(frozen=True)
class CompiledRule:
    rule_id: str
    group: str
    name: str
    targets: tuple[str, ...]
    regex: re.Pattern[str]
    weight: int
    severity: str


@dataclass
class InspectionDecision:
    action: str  # ALLOW | LOG | BLOCK | CHALLENGE
    rule_id: str
    rule_ids: list[str]
    attack_type: str
    severity: str
    confidence: float
    anomaly_score: int
    matched_location: str
    matched_excerpt: str
    reason: str
    metadata: dict[str, str] = field(default_factory=dict)


class InspectionEngine:
    """Thread-safe HTTP request inspection engine with Anomaly Scoring & SQL Lexer."""

    def __init__(self, rules_path: Path | str | None = None, threshold: int | None = None) -> None:
        path = Path(rules_path) if rules_path else DEFAULT_RULES_PATH
        raw_cfg = json.loads(path.read_text(encoding="utf-8"))
        self.threshold: int = threshold if threshold is not None else int(raw_cfg.get("anomaly_threshold", 5))
        self.rules: list[CompiledRule] = []
        for entry in raw_cfg.get("rules", []):
            self.rules.append(
                CompiledRule(
                    rule_id=entry["id"],
                    group=entry["group"],
                    name=entry["name"],
                    targets=tuple(entry["targets"]),
                    regex=re.compile(entry["pattern"], re.IGNORECASE),
                    weight=int(entry["weight"]),
                    severity=entry["severity"],
                )
            )

    def _target_matches_surface(self, targets: tuple[str, ...], location: str, name: str) -> bool:
        for t in targets:
            if t == location:
                return True
            if t.startswith("header:") and location == "header" and t.split(":", 1)[1] == name.lower():
                return True
        return False

    def inspect(
        self,
        method: str,
        path: str,
        raw_query: str = "",
        raw_body: bytes = b"",
        headers: dict[str, str] | None = None,
        waf_mode: str = "BLOCKING",
    ) -> InspectionDecision:
        """Analyze HTTP request components and produce structured security decision."""
        if waf_mode.upper() == "OFF":
            return InspectionDecision(
                action="ALLOW",
                rule_id="NONE",
                rule_ids=[],
                attack_type="Normal",
                severity="INFO",
                confidence=1.0,
                anomaly_score=0,
                matched_location="none",
                matched_excerpt="",
                reason="WAF is in OFF passthrough mode.",
            )

        parsed: ParsedHttpRequest = extract_http_components(
            method=method,
            path=path,
            raw_query=raw_query,
            raw_body=raw_body,
            headers=headers,
        )

        triggered_ids: list[str] = []
        triggered_groups: list[str] = []
        severities: list[str] = []
        matched_locations: list[str] = []
        matched_excerpts: list[str] = []
        reasons: list[str] = []
        total_score = 0

        # Skip benign CSRF / cookie inspection noise if rule only inspects payloads
        for surface in parsed.surfaces:
            if surface.location == "header" and surface.name in ("cookie", "referer"):
                # Still inspect Cookie/Referer for traversal/XSS/SQLi if maliciously crafted,
                # but do not apply SCN-01 user-agent rules to them.
                pass

            norm = normalize_for_inspection(surface.value)

            # Evaluate declarative regex rules on normalized views
            for rule in self.rules:
                if rule.rule_id in triggered_ids:
                    continue
                if not self._target_matches_surface(rule.targets, surface.location, surface.name):
                    continue
                hit = (
                    rule.regex.search(norm.spaced)
                    or rule.regex.search(norm.collapsed)
                    or rule.regex.search(surface.value)
                )
                if hit:
                    triggered_ids.append(rule.rule_id)
                    triggered_groups.append(rule.group)
                    severities.append(rule.severity)
                    matched_locations.append(f"{surface.location}:{surface.name}")
                    matched_excerpts.append(norm.decoded[:120])
                    reasons.append(f"{rule.rule_id} ({rule.name}, +{rule.weight})")
                    total_score += rule.weight

            # Evaluate structural SQL Lexical Tokenizer on query & body parameters (anti-evasion & 0% O'Brien FP)
            if surface.location in ("query", "query_hpp", "body", "query_key"):
                lex_res = analyze_sql_grammar(surface.value)
                if lex_res.suspicious_grammar and "SQL-05" not in triggered_ids:
                    triggered_ids.append("SQL-05")
                    triggered_groups.append("SQLi")
                    severities.append("HIGH")
                    matched_locations.append(f"{surface.location}:{surface.name}")
                    matched_excerpts.append(norm.decoded[:120])
                    reasons.append(f"SQL-05 (SQL Lexical Grammar [{lex_res.fingerprint}], +6)")
                    total_score += 6

        if total_score == 0:
            return InspectionDecision(
                action="ALLOW",
                rule_id="NONE",
                rule_ids=[],
                attack_type="Normal",
                severity="INFO",
                confidence=0.99,
                anomaly_score=0,
                matched_location="none",
                matched_excerpt="",
                reason="Clean request across all HTTP inspection surfaces.",
            )

        primary_group = triggered_groups[0]
        primary_rule = triggered_ids[0]
        severity_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
        top_severity = max(severities, key=lambda s: severity_rank.get(s, 0))
        confidence = round(min(0.99, 0.55 + (total_score / (self.threshold * 2.0)) * 0.44), 2)

        if total_score >= self.threshold:
            action = "BLOCK" if waf_mode.upper() == "BLOCKING" else "LOG"
        else:
            # Below threshold (e.g., O'Brien +2 < 5, or standalone User-Agent +3 < 5): allow safely
            action = "ALLOW" if waf_mode.upper() == "BLOCKING" else "LOG"

        return InspectionDecision(
            action=action,
            rule_id=primary_rule,
            rule_ids=triggered_ids,
            attack_type=primary_group,
            severity=top_severity,
            confidence=confidence,
            anomaly_score=total_score,
            matched_location=matched_locations[0],
            matched_excerpt=matched_excerpts[0],
            reason="; ".join(reasons),
        )
