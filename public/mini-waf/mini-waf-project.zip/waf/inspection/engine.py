"""
engine.py - Anomaly Scoring & Structured Decision Orchestrator.
Owned by Hùng (inspection/engine.py): dispatches parsed surfaces across normalizer,
sqli, xss, and traversal detectors and aggregates an Anomaly Score decision.
"""

from __future__ import annotations

import json
from pathlib import Path

from waf.inspection.normalizer import normalize_for_inspection
from waf.inspection.parser import ParsedHttpRequest, extract_http_components
from waf.inspection.sqli import RuleFinding, inspect_sqli
from waf.inspection.traversal import inspect_scanner_signals, inspect_traversal
from waf.inspection.xss import inspect_xss
from waf.protection.decision import InspectionDecision


DEFAULT_RULES_PATH = Path(__file__).resolve().parent.parent / "rules.json"


class InspectionEngine:
    """Combines parser, normalizer, and sqli/xss/traversal detectors with Anomaly Scoring."""

    def __init__(self, rules_path: Path | str | None = None, threshold: int | None = None) -> None:
        path = Path(rules_path) if rules_path else DEFAULT_RULES_PATH
        raw_cfg = json.loads(path.read_text(encoding="utf-8"))
        self.threshold: int = threshold if threshold is not None else int(raw_cfg.get("anomaly_threshold", 5))
        self.weights: dict[str, int] = {
            entry["id"]: int(entry["weight"]) for entry in raw_cfg.get("rules", [])
        }

    def inspect(
        self,
        method: str,
        path: str,
        raw_query: str = "",
        raw_body: bytes = b"",
        headers: dict[str, str] | None = None,
        waf_mode: str = "BLOCKING",
    ) -> InspectionDecision:
        if waf_mode.upper() == "OFF":
            return InspectionDecision(
                action="ALLOW",
                rule_id="NONE",
                rule_ids=[],
                attack_type="Normal",
                severity="INFO",
                confidence=1.0,
                anomaly_score=0,
                matched_location="none",
                matched_excerpt="",
                reason="WAF is in OFF passthrough mode.",
            )

        parsed: ParsedHttpRequest = extract_http_components(
            method=method,
            path=path,
            raw_query=raw_query,
            raw_body=raw_body,
            headers=headers,
        )

        triggered_ids: list[str] = []
        triggered_groups: list[str] = []
        severities: list[str] = []
        matched_locations: list[str] = []
        matched_excerpts: list[str] = []
        reasons: list[str] = []
        total_score = 0

        for surface in parsed.surfaces:
            norm = normalize_for_inspection(surface.value)
            findings: list[RuleFinding] = []

            if surface.location in ("query", "query_hpp", "body", "query_key"):
                findings.extend(inspect_sqli(surface.value, norm, self.weights))
            if surface.location in ("query", "query_hpp", "body", "path"):
                findings.extend(inspect_xss(surface.value, norm, self.weights))
                findings.extend(inspect_traversal(surface.value, norm, self.weights))
            findings.extend(inspect_scanner_signals(surface.location, surface.name, norm, self.weights))

            for f in findings:
                if f.rule_id in triggered_ids:
                    continue
                triggered_ids.append(f.rule_id)
                triggered_groups.append(f.group)
                severities.append(f.severity)
                matched_locations.append(f"{surface.location}:{surface.name}")
                matched_excerpts.append(norm.decoded[:120])
                reasons.append(f.reason)
                total_score += f.weight

        if total_score == 0:
            return InspectionDecision(
                action="ALLOW",
                rule_id="NONE",
                rule_ids=[],
                attack_type="Normal",
                severity="INFO",
                confidence=0.99,
                anomaly_score=0,
                matched_location="none",
                matched_excerpt="",
                reason="Clean request across all HTTP inspection surfaces.",
            )

        severity_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
        top_severity = max(severities, key=lambda s: severity_rank.get(s, 0))
        confidence = round(min(0.99, 0.55 + (total_score / (self.threshold * 2.0)) * 0.44), 2)
        action = (
            ("BLOCK" if waf_mode.upper() == "BLOCKING" else "LOG")
            if total_score >= self.threshold
            else ("ALLOW" if waf_mode.upper() == "BLOCKING" else "LOG")
        )

        return InspectionDecision(
            action=action,
            rule_id=triggered_ids[0],
            rule_ids=triggered_ids,
            attack_type=triggered_groups[0],
            severity=top_severity,
            confidence=confidence,
            anomaly_score=total_score,
            matched_location=matched_locations[0],
            matched_excerpt=matched_excerpts[0],
            reason="; ".join(reasons),
        )
