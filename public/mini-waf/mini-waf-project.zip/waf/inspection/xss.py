"""
xss.py - Cross-Site Scripting (XSS) Detector.
Owned by Hùng (inspection/xss.py): catches executable tags, inline event handlers,
and javascript:/vbscript: pseudo-URIs across decoded forms without false-blocking math (5 < 10).
"""

from __future__ import annotations

import re

from waf.inspection.normalizer import NormalizedViews
from waf.inspection.sqli import RuleFinding


XSS_PATTERN = re.compile(
    r"(?:<\s*/?\s*(?:script|iframe|svg|object|embed)\b)"
    r"|(?:<\s*(?:img|body|video|audio|details|a|input|marquee)\b[^>]*\bon(?:error|load|click|mouseover|focus|toggle|start)\s*=)"
    r"|(?:\bon(?:error|load|mouseover|focus)\s*=\s*['\"]?(?:alert|prompt|confirm|fetch|eval|document))"
    r"|(?:\b(?:javascript|vbscript)\s*:)",
    re.IGNORECASE,
)


def inspect_xss(raw_value: str, views: NormalizedViews, weights_override: dict[str, int] | None = None) -> list[RuleFinding]:
    candidates = (views.spaced, views.collapsed, raw_value)
    if any(XSS_PATTERN.search(c) for c in candidates):
        w = int((weights_override or {}).get("XSS-01", 5))
        return [
            RuleFinding(
                rule_id="XSS-01",
                group="XSS",
                weight=w,
                severity="HIGH",
                reason=f"XSS-01 (Executable HTML Tag / Event Attribute / JS URI, +{w})",
            )
        ]
    return []
