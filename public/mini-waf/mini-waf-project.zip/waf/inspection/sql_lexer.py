"""
sql_lexer.py - Context-Aware SQL Lexical Tokenizer.
Distinguishes benign apostrophes in real names (e.g. O'Brien, D'Angelo) from
structural SQL injection grammar (tautology breakout, UNION SELECT, timed probes).
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from waf.inspection.normalizer import normalize_for_inspection


SQL_KEYWORDS = frozenset(
    {
        "SELECT",
        "UNION",
        "ALL",
        "FROM",
        "WHERE",
        "AND",
        "OR",
        "XOR",
        "ORDER",
        "BY",
        "GROUP",
        "HAVING",
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "ALTER",
        "SLEEP",
        "BENCHMARK",
        "WAITFOR",
        "DELAY",
        "CONCAT",
        "GROUP_CONCAT",
        "SUBSTRING",
        "SUBSTR",
        "ASCII",
        "CHAR",
        "INFORMATION_SCHEMA",
        "SQLITE_MASTER",
        "OUTFILE",
        "DUMPFILE",
        "LOAD_FILE",
        "INTO",
        "NULL",
        "EXTRACTVALUE",
        "UPDATEXML",
        "TRUE",
        "FALSE",
    }
)


@dataclass(frozen=True)
class SqlToken:
    kind: str  # n=number, s=string, o=operator/delimiter, k=keyword, w=word/ident, c=comment
    lexeme: str


@dataclass(frozen=True)
class SqlLexicalAnalysis:
    suspicious_grammar: bool
    fingerprint: str
    reason: str


def tokenize_sql(text: str) -> list[SqlToken]:
    """Scan a SQL-normalized text fragment into lexical tokens."""
    tokens: list[SqlToken] = []
    i = 0
    n = len(text)

    while i < n and len(tokens) < 96:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue

        if ch == "#" or text[i : i + 2] == "--":
            tokens.append(SqlToken("c", text[i : i + 32]))
            break

        if ch in ("'", '"'):
            quote = ch
            j = i + 1
            while j < n and text[j] != quote:
                j += 1
            if j < n:
                tokens.append(SqlToken("s", text[i : j + 1]))
                i = j + 1
            else:
                tokens.append(SqlToken("o", quote))
                i += 1
            continue

        if text[i : i + 2] in ("<=", ">=", "<>", "!=", "||", "&&"):
            tokens.append(SqlToken("o", text[i : i + 2]))
            i += 2
            continue

        if ch in ("=", "<", ">", "(", ")", ",", ";", "+", "-", "*", "/"):
            tokens.append(SqlToken("o", ch))
            i += 1
            continue

        if ch.isdigit():
            m = re.match(r"0x[0-9a-fA-F]+|\d+(?:\.\d+)?", text[i:])
            if m:
                lex = m.group(0)
                tokens.append(SqlToken("n", lex))
                i += len(lex)
                continue

        if ch.isalpha() or ch in ("_", "@", "."):
            m = re.match(r"[A-Za-z_@.][A-Za-z0-9_@.$]*", text[i:])
            if m:
                lex = m.group(0)
                kind = "k" if lex.upper() in SQL_KEYWORDS else "w"
                tokens.append(SqlToken(kind, lex))
                i += len(lex)
                continue

        tokens.append(SqlToken("o", ch))
        i += 1

    return tokens


def analyze_sql_grammar(raw_value: str) -> SqlLexicalAnalysis:
    """
    Evaluate whether input exhibits structural SQL injection grammar rather than
    benign text containing an apostrophe (such as O'Brien or D'Angelo) or math prose (5 < 10).
    """
    views = normalize_for_inspection(raw_value)
    for variant in (views.spaced, views.collapsed):
        tokens = tokenize_sql(variant)
        if not tokens:
            continue
        fingerprint = "".join(t.kind for t in tokens[:8])
        kws = [t.lexeme.upper() for t in tokens if t.kind == "k"]
        ops = [t.lexeme for t in tokens if t.kind == "o"]
        has_comment = any(t.kind == "c" for t in tokens)
        has_unmatched_quote = "'" in ops or '"' in ops
        has_quoted_str = any(t.kind == "s" for t in tokens)
        has_eq = "=" in ops

        # Rule A: Structural UNION + SELECT sequence (handles comment-split evasion)
        if "UNION" in kws and "SELECT" in kws:
            return SqlLexicalAnalysis(
                suspicious_grammar=True,
                fingerprint=fingerprint,
                reason="Detected structural UNION + SELECT token sequence after normalization.",
            )

        # Rule B: Quote breakout followed by boolean operator + comparison or comment
        if (has_unmatched_quote or has_quoted_str) and any(k in ("OR", "AND", "XOR") for k in kws):
            if has_eq or has_comment or "TRUE" in kws:
                return SqlLexicalAnalysis(
                    suspicious_grammar=True,
                    fingerprint=fingerprint,
                    reason="Detected quote-context breakout with SQL boolean logic and comparator/comment.",
                )

        # Rule C: Privileged / timed / blind SQL functions called with '(' or metadata tables
        dangerous_funcs = {
            "SLEEP",
            "BENCHMARK",
            "WAITFOR",
            "ASCII",
            "SUBSTRING",
            "SUBSTR",
            "EXTRACTVALUE",
            "UPDATEXML",
            "LOAD_FILE",
            "GROUP_CONCAT",
        }
        if any(k in dangerous_funcs for k in kws) and "(" in ops:
            return SqlLexicalAnalysis(
                suspicious_grammar=True,
                fingerprint=fingerprint,
                reason="Detected SQL injection timing/blind/exfiltration function invocation.",
            )

        if any(k in ("INFORMATION_SCHEMA", "SQLITE_MASTER", "OUTFILE", "DUMPFILE") for k in kws):
            return SqlLexicalAnalysis(
                suspicious_grammar=True,
                fingerprint=fingerprint,
                reason="Detected internal metadata schema or file export keyword.",
            )

        # Rule D: Query stacking '; DROP/SELECT/DELETE/INSERT/UPDATE'
        for idx, tok in enumerate(tokens[:-1]):
            if tok.lexeme == ";" and tokens[idx + 1].kind == "k":
                if tokens[idx + 1].lexeme.upper() in ("SELECT", "DROP", "DELETE", "INSERT", "UPDATE", "ALTER"):
                    return SqlLexicalAnalysis(
                        suspicious_grammar=True,
                        fingerprint=fingerprint,
                        reason="Detected stacked SQL command after semicolon delimiter.",
                    )

    return SqlLexicalAnalysis(
        suspicious_grammar=False,
        fingerprint=fingerprint if tokens else "",
        reason="No structural SQL injection grammar found.",
    )
