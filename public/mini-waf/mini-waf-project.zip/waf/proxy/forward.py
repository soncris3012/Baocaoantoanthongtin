"""
forward.py - Async Upstream HTTPX Forwarding, Traceback Scrubbing & Header Hardening.
Owned by Sơn (main.py, proxy/server.py, proxy/forward.py, target_web/, docker-compose.yml).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

import httpx
from fastapi import Request, Response
from fastapi.responses import JSONResponse

from waf.database.repository import WafRepository
from waf.inspection.engine import InspectionEngine
from waf.protection.decision import ActiveDefenseManager
from waf.protection.defense import harden_response_headers


@dataclass
class WafRuntime:
    upstream_url: str
    mode: str  # OFF | MONITOR | BLOCKING
    engine: InspectionEngine
    defense: ActiveDefenseManager
    repo: WafRepository
    admin_token: str
    admin_password: str
    telegram_sent_log: list[str] = field(default_factory=list)
    http_client: httpx.AsyncClient | None = None

    @classmethod
    def from_env(
        cls,
        db_path: str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> "WafRuntime":
        proxies_raw = os.getenv("TRUSTED_PROXIES", "127.0.0.1,::1")
        trusted = tuple(p.strip() for p in proxies_raw.split(",") if p.strip())
        threshold = int(os.getenv("ANOMALY_THRESHOLD", "5"))
        return cls(
            upstream_url=os.getenv("UPSTREAM_URL", "http://127.0.0.1:8000").rstrip("/"),
            mode=os.getenv("WAF_MODE", "BLOCKING").upper(),
            engine=InspectionEngine(threshold=threshold),
            defense=ActiveDefenseManager(
                rate_algo=os.getenv("RATE_LIMIT_ALGO", "sliding"),
                max_requests=int(os.getenv("RATE_LIMIT_MAX_REQUESTS", "30")),
                window_sec=int(os.getenv("RATE_LIMIT_WINDOW_SEC", "10")),
                violation_threshold=int(os.getenv("AUTOBAN_VIOLATIONS", "3")),
                violation_window_sec=int(os.getenv("AUTOBAN_WINDOW_SEC", "60")),
                ban_ttl_sec=int(os.getenv("AUTOBAN_TTL_SEC", "300")),
                trusted_proxies=trusted,
            ),
            repo=WafRepository(db_path or os.getenv("WAF_DB_PATH", "/tmp/waf_logs.db")),
            admin_token=os.getenv("ADMIN_TOKEN", "miniwaf-admin-2026"),
            admin_password=os.getenv("ADMIN_PASSWORD", "miniwaf-admin-2026"),
            http_client=http_client,
        )


async def forward_to_upstream(
    runtime: WafRuntime,
    request: Request,
    raw_path: str,
    raw_query: str,
    raw_body: bytes,
    client_ip: str,
) -> Response:
    """Forward clean/monitored requests asynchronously to isolated upstream web container."""
    assert runtime.http_client is not None
    forward_url = f"{raw_path}?{raw_query}" if raw_query else raw_path
    hop_by_hop = {"host", "content-length", "connection", "keep-alive"}
    fwd_headers = [(k, v) for k, v in request.headers.items() if k.lower() not in hop_by_hop]
    fwd_headers.append(("x-forwarded-for", client_ip))

    try:
        upstream_resp = await runtime.http_client.request(
            method=request.method,
            url=forward_url,
            content=raw_body,
            headers=fwd_headers,
        )
    except httpx.TimeoutException:
        return JSONResponse(
            status_code=504,
            content={"detail": "Upstream Web Server timed out"},
            headers={"X-WAF-Protected-By": "Mini-WAF-v2"},
        )
    except httpx.RequestError:
        return JSONResponse(
            status_code=502,
            content={"detail": "Upstream Web Server unreachable"},
            headers={"X-WAF-Protected-By": "Mini-WAF-v2"},
        )

    resp_body = upstream_resp.content
    resp_headers = list(upstream_resp.headers.multi_items())

    if upstream_resp.status_code >= 500 and runtime.mode != "OFF":
        resp_body = b'{"detail":"Internal Application Error (sanitized by Mini-WAF)"}'
        resp_headers = [(k, v) for k, v in resp_headers if k.lower() != "content-type"]
        resp_headers.append(("Content-Type", "application/json"))

    if runtime.mode != "OFF":
        resp_headers = harden_response_headers(resp_headers)
    else:
        resp_headers = [
            (k, v)
            for k, v in resp_headers
            if k.lower() not in {"content-length", "transfer-encoding"}
        ]

    out_response = Response(content=resp_body, status_code=upstream_resp.status_code)
    for name, val in resp_headers:
        out_response.headers.append(name, val)
    return out_response
