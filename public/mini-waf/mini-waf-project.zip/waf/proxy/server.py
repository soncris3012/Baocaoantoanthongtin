"""
server.py - FastAPI Reverse Proxy Request Pipeline (Port 8080).
Owned by Sơn (proxy/server.py): coordinates early defense gate, inspection engine,
blocking + alerting, and clean upstream forwarding via proxy/forward.py.
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse

from waf.monitoring.logger import build_sanitized_event
from waf.monitoring.telegram_alert import trigger_telegram_alert
from waf.proxy.forward import WafRuntime, forward_to_upstream


BLOCKED_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8" />
  <title>403 Forbidden - Mini-WAF Security Block</title>
  <style>
    body {{ font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f8fafc; padding: 3rem; }}
    .card {{ max-width: 600px; margin: 0 auto; background: #1e293b; border: 1px solid #ef4444; border-radius: 10px; padding: 24px; }}
    h1 {{ color: #f87171; font-size: 20px; margin-top: 0; }}
    code {{ background: #0f172a; padding: 2px 6px; border-radius: 4px; color: #fbbf24; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>403 Forbidden — Yêu cầu bị chặn bởi Mini-WAF</h1>
    <p>Hệ thống phòng thủ tầng biên phát hiện dấu hiệu vi phạm chính sách bảo mật.</p>
    <p>Mã sự cố: <code>{rule_id}</code> · Nhóm: <code>{attack_type}</code> · Điểm rủi ro: <code>{score}</code></p>
    <p style="font-size: 13px; color: #94a3b8;">Client IP: {client_ip} · Action: {action}</p>
  </div>
</body>
</html>
"""


def create_proxy_app(runtime: WafRuntime) -> FastAPI:
    """Create the Reverse Proxy ASGI application serving client traffic on port 8080."""
    owns_client = runtime.http_client is None

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        await runtime.repo.init()
        if runtime.http_client is None:
            runtime.http_client = httpx.AsyncClient(
                base_url=runtime.upstream_url,
                timeout=httpx.Timeout(10.0, connect=3.0),
                follow_redirects=False,
            )
        try:
            yield
        finally:
            if owns_client and runtime.http_client is not None:
                await runtime.http_client.aclose()

    app = FastAPI(title="Mini-WAF Reverse Proxy", docs_url=None, redoc_url=None, lifespan=lifespan)
    app.state.runtime = runtime

    @app.api_route("/{full_path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
    async def handle_request(request: Request, full_path: str) -> Response:
        started = time.perf_counter()
        raw_path = request.url.path or "/"
        raw_query = request.url.query or ""
        raw_body = await request.body()
        req_headers = dict(request.headers)
        peer_ip = request.client.host if request.client else "127.0.0.1"
        xff = req_headers.get("x-forwarded-for")

        # 1. Early Active Defense check (Trusted IP + Blacklist O(1) + Rate Limit)
        if runtime.mode != "OFF":
            pre = runtime.defense.pre_check(peer_ip=peer_ip, x_forwarded_for=xff)
            client_ip = pre.client_ip
            if not pre.allowed:
                elapsed_ms = (time.perf_counter() - started) * 1000.0
                await runtime.repo.log_event(
                    build_sanitized_event(
                        client_ip=client_ip,
                        method=request.method,
                        path=raw_path,
                        raw_snippet=raw_query or pre.reason,
                        rule_ids=["RL-429" if pre.status_code == 429 else "BAN-403"],
                        category="RateLimit" if pre.status_code == 429 else "Blacklist",
                        anomaly_score=10,
                        action=pre.action,
                        latency_ms=elapsed_ms,
                    )
                )
                headers = {"X-WAF-Protected-By": "Mini-WAF-v2"}
                if pre.retry_after_sec > 0:
                    headers["Retry-After"] = str(pre.retry_after_sec)
                return JSONResponse(
                    status_code=pre.status_code,
                    content={"detail": pre.reason, "action": pre.action, "client_ip": client_ip},
                    headers=headers,
                )
        else:
            client_ip = runtime.defense.resolve_ip(peer_ip, xff)

        # 2. Content Inspection Engine
        decision = runtime.engine.inspect(
            method=request.method,
            path=raw_path,
            raw_query=raw_query,
            raw_body=raw_body,
            headers=req_headers,
            waf_mode=runtime.mode,
        )

        # 3. Blocking path (does NOT reach backend Web Server)
        if decision.action == "BLOCK":
            ban_rec = runtime.defense.on_waf_block(client_ip=client_ip, rule_id=decision.rule_id)
            if ban_rec is not None:
                await runtime.repo.upsert_ban(
                    ip=ban_rec.ip,
                    reason=ban_rec.reason,
                    banned_at=ban_rec.banned_at_iso,
                    expires_at=ban_rec.expires_at_iso,
                )
                trigger_telegram_alert(
                    attack_type=f"{decision.attack_type} -> AUTO-BAN",
                    client_ip=client_ip,
                    rule_ids=decision.rule_ids,
                    action="BANNED (TTL 300s)",
                    sent_log=runtime.telegram_sent_log,
                )
            elif decision.severity in ("HIGH", "CRITICAL"):
                trigger_telegram_alert(
                    attack_type=decision.attack_type,
                    client_ip=client_ip,
                    rule_ids=decision.rule_ids,
                    action="BLOCK",
                    sent_log=runtime.telegram_sent_log,
                )

            elapsed_ms = (time.perf_counter() - started) * 1000.0
            snippet_source = decision.matched_excerpt or raw_query or raw_body.decode("utf-8", errors="replace")
            await runtime.repo.log_event(
                build_sanitized_event(
                    client_ip=client_ip,
                    method=request.method,
                    path=raw_path,
                    raw_snippet=snippet_source,
                    rule_ids=decision.rule_ids,
                    category=decision.attack_type,
                    anomaly_score=decision.anomaly_score,
                    action="BLOCKED",
                    latency_ms=elapsed_ms,
                )
            )
            accept = req_headers.get("accept", "")
            if "application/json" in accept:
                return JSONResponse(
                    status_code=403,
                    content={
                        "action": "BLOCK",
                        "rule_id": decision.rule_id,
                        "rule_ids": decision.rule_ids,
                        "attack_type": decision.attack_type,
                        "severity": decision.severity,
                        "confidence": decision.confidence,
                        "anomaly_score": decision.anomaly_score,
                    },
                    headers={"X-WAF-Protected-By": "Mini-WAF-v2"},
                )
            return HTMLResponse(
                status_code=403,
                content=BLOCKED_HTML.format(
                    rule_id=decision.rule_id,
                    attack_type=decision.attack_type,
                    score=decision.anomaly_score,
                    client_ip=client_ip,
                    action=decision.action,
                ),
                headers={"X-WAF-Protected-By": "Mini-WAF-v2"},
            )

        # 4. Forward clean or MONITOR request asynchronously via proxy/forward.py
        out_response = await forward_to_upstream(
            runtime=runtime,
            request=request,
            raw_path=raw_path,
            raw_query=raw_query,
            raw_body=raw_body,
            client_ip=client_ip,
        )

        elapsed_ms = (time.perf_counter() - started) * 1000.0
        log_action = (
            "MONITORED"
            if (decision.action == "LOG" and decision.anomaly_score >= runtime.engine.threshold)
            else "ALLOWED"
        )
        if runtime.mode != "OFF":
            await runtime.repo.log_event(
                build_sanitized_event(
                    client_ip=client_ip,
                    method=request.method,
                    path=raw_path,
                    raw_snippet=raw_query or raw_body.decode("utf-8", errors="replace"),
                    rule_ids=decision.rule_ids,
                    category=decision.attack_type,
                    anomaly_score=decision.anomaly_score,
                    action=log_action,
                    latency_ms=elapsed_ms,
                )
            )
        return out_response

    return app
