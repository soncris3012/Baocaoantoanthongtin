"""
models.py - SQLite Schema & Data Structures for Mini-WAF Security Events & Blacklist.
"""

from __future__ import annotations

from dataclasses import dataclass


SCHEMA_SQL = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS security_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    client_ip TEXT NOT NULL,
    method TEXT NOT NULL,
    path TEXT NOT NULL,
    payload_snippet TEXT,
    rule_ids TEXT,
    category TEXT,
    anomaly_score INTEGER DEFAULT 0,
    action TEXT NOT NULL,
    latency_ms REAL DEFAULT 0.0
);

CREATE INDEX IF NOT EXISTS idx_security_logs_ts ON security_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_security_logs_action ON security_logs(action);

CREATE TABLE IF NOT EXISTS banned_ips (
    ip TEXT PRIMARY KEY,
    reason TEXT NOT NULL,
    banned_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);
"""


@dataclass
class SecurityEventRecord:
    timestamp: str
    client_ip: str
    method: str
    path: str
    payload_snippet: str
    rule_ids: str
    category: str
    anomaly_score: int
    action: str  # ALLOWED | MONITORED | BLOCKED | RATE_LIMITED | BANNED
    latency_ms: float
