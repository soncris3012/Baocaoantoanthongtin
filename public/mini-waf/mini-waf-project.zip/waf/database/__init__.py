"""SQLite async persistence package (WAL mode)."""
