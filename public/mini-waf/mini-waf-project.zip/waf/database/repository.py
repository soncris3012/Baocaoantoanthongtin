"""
repository.py - Async SQLite WAL Repository for Security Events, Active Blacklist & Dashboard Stats.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from pathlib import Path

import aiosqlite

from waf.database.models import SCHEMA_SQL, SecurityEventRecord


UTC_PLUS_7 = timezone(timedelta(hours=7))


class WafRepository:
    """Async repository backed by SQLite in WAL mode."""

    def __init__(self, db_path: str | Path = "/tmp/waf_logs.db") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_lock = asyncio.Lock()
        self._initialized = False

    async def init(self) -> None:
        async with self._init_lock:
            if self._initialized:
                return
            async with aiosqlite.connect(self.db_path) as db:
                await db.executescript(SCHEMA_SQL)
                await db.commit()
            self._initialized = True

    async def log_event(self, event: SecurityEventRecord) -> None:
        if not self._initialized:
            await self.init()
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO security_logs (
                    timestamp, client_ip, method, path, payload_snippet,
                    rule_ids, category, anomaly_score, action, latency_ms
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event.timestamp,
                    event.client_ip,
                    event.method,
                    event.path,
                    event.payload_snippet,
                    event.rule_ids,
                    event.category,
                    event.anomaly_score,
                    event.action,
                    round(event.latency_ms, 3),
                ),
            )
            await db.commit()

    async def upsert_ban(self, ip: str, reason: str, banned_at: str, expires_at: str) -> None:
        if not self._initialized:
            await self.init()
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO banned_ips (ip, reason, banned_at, expires_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(ip) DO UPDATE SET
                    reason=excluded.reason,
                    banned_at=excluded.banned_at,
                    expires_at=excluded.expires_at
                """,
                (ip, reason, banned_at, expires_at),
            )
            await db.commit()

    async def remove_ban(self, ip: str) -> None:
        if not self._initialized:
            await self.init()
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM banned_ips WHERE ip = ?", (ip,))
            await db.commit()

    async def purge_expired_bans(self) -> None:
        if not self._initialized:
            await self.init()
        now_iso = datetime.now(tz=UTC_PLUS_7).isoformat(timespec="seconds")
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM banned_ips WHERE expires_at <= ?", (now_iso,))
            await db.commit()

    async def get_stats(self, limit_logs: int = 40) -> dict[str, object]:
        if not self._initialized:
            await self.init()
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row

            cur = await db.execute(
                """
                SELECT
                    COUNT(*) AS total_requests,
                    SUM(CASE WHEN action = 'ALLOWED' THEN 1 ELSE 0 END) AS allowed_count,
                    SUM(CASE WHEN action = 'MONITORED' THEN 1 ELSE 0 END) AS monitored_count,
                    SUM(CASE WHEN action IN ('BLOCKED', 'BANNED') THEN 1 ELSE 0 END) AS blocked_count,
                    SUM(CASE WHEN action = 'RATE_LIMITED' THEN 1 ELSE 0 END) AS rate_limited_count,
                    AVG(latency_ms) AS avg_latency_ms
                FROM security_logs
                """
            )
            summary_row = await cur.fetchone()
            total = int(summary_row["total_requests"] or 0)
            allowed = int(summary_row["allowed_count"] or 0)
            monitored = int(summary_row["monitored_count"] or 0)
            blocked = int(summary_row["blocked_count"] or 0)
            rate_limited = int(summary_row["rate_limited_count"] or 0)
            avg_latency = round(float(summary_row["avg_latency_ms"] or 0.0), 2)

            cat_cur = await db.execute(
                """
                SELECT category, COUNT(*) AS cnt
                FROM security_logs
                WHERE action != 'ALLOWED'
                GROUP BY category
                ORDER BY cnt DESC
                """
            )
            categories = [
                {"category": row["category"] or "Other", "count": int(row["cnt"])}
                for row in await cat_cur.fetchall()
            ]

            series_cur = await db.execute(
                """
                SELECT
                    substr(timestamp, 12, 8) AS sec_bucket,
                    COUNT(*) AS total,
                    SUM(CASE WHEN action != 'ALLOWED' THEN 1 ELSE 0 END) AS flagged
                FROM security_logs
                GROUP BY sec_bucket
                ORDER BY sec_bucket DESC
                LIMIT 18
                """
            )
            timeline = list(reversed([dict(r) for r in await series_cur.fetchall()]))

            logs_cur = await db.execute(
                """
                SELECT id, timestamp, client_ip, method, path, payload_snippet,
                       rule_ids, category, anomaly_score, action, latency_ms
                FROM security_logs
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit_logs,),
            )
            recent_logs = [dict(r) for r in await logs_cur.fetchall()]

        # Compute recent 20-event spike alert (> 50% malicious within latest 20 requests when >= 6 requests exist)
        recent_slice = recent_logs[:20]
        recent_flagged = sum(1 for row in recent_slice if row["action"] in ("BLOCKED", "RATE_LIMITED", "BANNED"))
        spike_alert = len(recent_slice) >= 6 and (recent_flagged / len(recent_slice)) >= 0.5

        total_prevented = blocked + rate_limited
        block_rate_pct = round((total_prevented / total) * 100, 1) if total > 0 else 0.0

        return {
            "total_requests": total,
            "allowed_count": allowed,
            "monitored_count": monitored,
            "blocked_count": blocked,
            "rate_limited_count": rate_limited,
            "block_rate_pct": block_rate_pct,
            "avg_latency_ms": avg_latency,
            "categories": categories,
            "timeline": timeline,
            "recent_logs": recent_logs,
            "spike_alert": spike_alert,
        }
