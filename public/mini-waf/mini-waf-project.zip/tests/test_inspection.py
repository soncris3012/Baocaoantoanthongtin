"""Unit tests for Mini-WAF HTTP parser, normalizer, SQL lexical analyzer, and rules engine."""

from waf.inspection.engine import InspectionEngine


def test_evasion_double_url_and_comments_blocked():
    engine = InspectionEngine()
    payloads = [
        "/search?q=1%2527%2520OR%25201%253D1--",
        "/search?q=1' UN/**/ION SEL/**/ECT user,password FROM users#",
        "/search?q=1' /*!50000UNION*/ /*!50000SELECT*/ 1,2,3#",
        "/download?file=....//....//etc/passwd",
        "/download?file=tailieu.pdf%00.png",
    ]
    for full in payloads:
        path, _, query = full.partition("?")
        dec = engine.inspect("GET", path, raw_query=query, waf_mode="BLOCKING")
        assert dec.action == "BLOCK", f"Expected BLOCK for {full}, got {dec}"
        assert dec.anomaly_score >= 5


def test_hpp_and_json_nested_unicode_blocked():
    engine = InspectionEngine()
    # HTTP Parameter Pollution splitting SQL across repeated ?q= keys
    dec_hpp = engine.inspect("GET", "/search", raw_query="q=1'&q=OR 1=1--", waf_mode="BLOCKING")
    assert dec_hpp.action == "BLOCK"

    # JSON nested unicode \u0027 escape
    body = b'{"student":{"query":"admin\\u0027 OR \\u00271\\u0027=\\u00271"}}'
    dec_json = engine.inspect(
        "POST",
        "/login",
        raw_body=body,
        headers={"content-type": "application/json"},
        waf_mode="BLOCKING",
    )
    assert dec_json.action == "BLOCK"


def test_hard_benign_apostrophe_and_math_allowed():
    engine = InspectionEngine()
    for q in ["q=O'Brien", "q=D'Angelo", "msg=5%20%3C%2010", "msg=select%20option%20from%20menu"]:
        dec = engine.inspect("GET", "/search", raw_query=q, waf_mode="BLOCKING")
        assert dec.action == "ALLOW", f"False positive on benign query '{q}': {dec}"


def test_user_agent_not_blindly_blocking_without_probe():
    engine = InspectionEngine()
    # Benign endpoint with spoofable UA scores +3 (< 5) -> ALLOW instead of blind false ban
    dec_ua_only = engine.inspect(
        "GET",
        "/search",
        raw_query="q=SV001",
        headers={"user-agent": "sqlmap/1.8"},
        waf_mode="BLOCKING",
    )
    assert dec_ua_only.anomaly_score == 3
    assert dec_ua_only.action == "ALLOW"

    # Scanner UA + sensitive probe /.env scores +3 + 3 = 6 >= 5 -> BLOCK
    dec_combo = engine.inspect(
        "GET",
        "/.env",
        headers={"user-agent": "Nikto/2.5"},
        waf_mode="BLOCKING",
    )
    assert dec_combo.action == "BLOCK"
    assert dec_combo.anomaly_score >= 5
