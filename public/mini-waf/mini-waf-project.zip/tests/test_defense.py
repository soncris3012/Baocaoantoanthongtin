"""Unit tests for Rate Limiting (Fixed vs Sliding), Auto-Ban TTL, XFF anti-spoofing & Masking."""

from waf.monitoring.logger import sanitize_snippet
from waf.protection.blacklist import AutoBanManager
from waf.protection.client_ip import resolve_client_ip
from waf.protection.defense import harden_response_headers
from waf.protection.rate_limit import FixedWindowLimiter, SlidingWindowLimiter


def test_sliding_window_prevents_fixed_boundary_spike():
    fixed = FixedWindowLimiter(max_requests=5, window_sec=10)
    sliding = SlidingWindowLimiter(max_requests=5, window_sec=10)

    # 5 requests at t=9.5 (right before 10s fixed boundary) + 5 requests at t=10.2
    for t in [9.5] * 5:
        assert fixed.check("10.0.0.1", now=t).allowed
        assert sliding.check("10.0.0.1", now=t).allowed

    # Fixed window resets completely at t=10.0, letting 5 more through (10 reqs in 0.7s!)
    fixed_post = [fixed.check("10.0.0.1", now=10.2).allowed for _ in range(5)]
    sliding_post = [sliding.check("10.0.0.1", now=10.2).allowed for _ in range(5)]
    assert all(fixed_post)
    assert not any(sliding_post)


def test_autoban_ttl_and_manual_unban():
    mgr = AutoBanManager(violation_threshold=3, violation_window_sec=60, ban_ttl_sec=300)
    t0 = 1000.0
    assert mgr.record_violation("192.168.1.50", "SQL-02", now_epoch=t0) is None
    assert mgr.record_violation("192.168.1.50", "SQL-03", now_epoch=t0 + 5) is None
    ban = mgr.record_violation("192.168.1.50", "XSS-01", now_epoch=t0 + 10)
    assert ban is not None
    assert mgr.is_banned("192.168.1.50", now_epoch=t0 + 50) is not None

    # Expires naturally after TTL
    assert mgr.is_banned("192.168.1.50", now_epoch=t0 + 320) is None

    # Re-ban then unban manually
    for d in (0, 1, 2):
        mgr.record_violation("192.168.1.50", "SQL-02", now_epoch=t0 + 500 + d)
    assert mgr.unban("192.168.1.50") is True
    assert mgr.is_banned("192.168.1.50", now_epoch=t0 + 505) is None


def test_xff_anti_spoofing_and_log_masking():
    # Untrusted peer cannot spoof client IP
    assert resolve_client_ip("203.0.113.9", "1.2.3.4", trusted_proxies=("127.0.0.1",)) == "203.0.113.9"
    # Trusted local reverse proxy XFF IS honored
    assert resolve_client_ip("127.0.0.1", "198.51.100.77, 127.0.0.1", trusted_proxies=("127.0.0.1",)) == "198.51.100.77"

    masked = sanitize_snippet("username=admin&password=MySecret123&Cookie=PHPSESSID=abcxyz Authorization: Bearer eyJhbGciOiJIUzI1NiJ9")
    assert "MySecret123" not in masked
    assert "eyJhbGci" not in masked
    assert "***MASKED***" in masked


def test_response_header_hardening():
    raw = [
        ("Server", "Apache/2.4.25 (Debian)"),
        ("X-Powered-By", "PHP/7.1"),
        ("Set-Cookie", "portal_session=xyz; path=/"),
    ]
    hardened = harden_response_headers(raw)
    keys = {k.lower(): v for k, v in hardened}
    assert "server" not in keys
    assert "x-powered-by" not in keys
    assert "HttpOnly" in keys["set-cookie"] and "SameSite=Lax" in keys["set-cookie"]
    assert keys["x-content-type-options"] == "nosniff"
    assert keys["x-frame-options"] == "DENY"
