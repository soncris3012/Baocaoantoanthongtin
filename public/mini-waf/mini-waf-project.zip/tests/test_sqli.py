"""
test_sqli.py - Unit Tests for SQL Injection Detection & Anti-Evasion (Khánh & Hùng).
Tests Double-URL decoding, SQL comment stripping, HPP, nested JSON unicode,
benign apostrophe allowance (O'Brien, D'Angelo), and soft User-Agent scoring.
"""

from waf.inspection.engine import InspectionEngine


def test_sqli_evasion_techniques_blocked():
    engine = InspectionEngine()
    vectors = [
        "/search?q=' OR '1'='1",
        "/grades?masv=1' OR 1=1--",
        "/search?q=1%2527%2520OR%25201%253D1--",
        "/search?q=1' UN/**/ION SEL/**/ECT user,password FROM users#",
        "/search?q=1' /*!50000UNION*/ /*!50000SELECT*/ 1,2,3#",
        "/search?q=1' AND SLEEP(5)#",
    ]
    for url in vectors:
        path, _, query = url.partition("?")
        dec = engine.inspect("GET", path, raw_query=query, waf_mode="BLOCKING")
        assert dec.action == "BLOCK", f"Failed to block {url}: {dec}"
        assert dec.anomaly_score >= 5


def test_sqli_hpp_and_nested_json_blocked():
    engine = InspectionEngine()
    dec_hpp = engine.inspect("GET", "/search", raw_query="q=SV001&q=' OR 1=1--", waf_mode="BLOCKING")
    assert dec_hpp.action == "BLOCK"

    body = b'{"student":{"query":"admin\\u0027 OR \\u00271\\u0027=\\u00271"}}'
    dec_json = engine.inspect(
        "POST",
        "/login",
        raw_body=body,
        headers={"content-type": "application/json"},
        waf_mode="BLOCKING",
    )
    assert dec_json.action == "BLOCK"


def test_benign_apostrophe_names_not_false_blocked():
    engine = InspectionEngine()
    for name in ("O'Brien", "D'Angelo", "O'Connor", "Marco D'Angelo"):
        dec = engine.inspect("GET", "/search", raw_query=f"q={name}", waf_mode="BLOCKING")
        assert dec.action == "ALLOW", f"False positive on '{name}': {dec}"
        assert dec.anomaly_score < 5


def test_scanner_ua_soft_weight_only_blocks_with_probe():
    engine = InspectionEngine()
    dec_ua_only = engine.inspect(
        "GET",
        "/search",
        raw_query="q=SV001",
        headers={"user-agent": "sqlmap/1.8.4#stable"},
        waf_mode="BLOCKING",
    )
    assert dec_ua_only.anomaly_score == 3
    assert dec_ua_only.action == "ALLOW"

    dec_ua_and_probe = engine.inspect(
        "GET",
        "/.env",
        headers={"user-agent": "Nikto/2.5.0"},
        waf_mode="BLOCKING",
    )
    assert dec_ua_and_probe.action == "BLOCK"
    assert dec_ua_and_probe.anomaly_score >= 5
