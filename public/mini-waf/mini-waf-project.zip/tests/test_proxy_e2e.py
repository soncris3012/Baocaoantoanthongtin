"""End-to-end integration tests wiring Proxy (:8080), Target Web (:8000), and Admin Dashboard (:8888)."""

from pathlib import Path

import httpx
import pytest

from target_web.app import create_target_app
from waf.monitoring.dashboard import create_admin_app
from waf.proxy.forward import WafRuntime, create_proxy_app


@pytest.mark.anyio
async def test_proxy_dashboard_separation_and_auth_and_end_to_end(tmp_path: Path):
    target_app = create_target_app(db_path=tmp_path / "target.db", docs_dir=tmp_path / "docs")
    upstream_transport = httpx.ASGITransport(app=target_app)
    upstream_client = httpx.AsyncClient(base_url="http://target_web:8000", transport=upstream_transport)

    runtime = WafRuntime.from_env(db_path=str(tmp_path / "waf.db"), http_client=upstream_client)
    proxy_app = create_proxy_app(runtime)
    admin_app = create_admin_app(runtime)

    try:
        async with (
            httpx.AsyncClient(base_url="http://proxy:8080", transport=httpx.ASGITransport(app=proxy_app)) as proxy_cli,
            httpx.AsyncClient(base_url="http://admin:8888", transport=httpx.ASGITransport(app=admin_app)) as admin_cli,
        ):
            # 1. Port 8080 does NOT expose Admin APIs
            r_iso = await proxy_cli.get("/api/stats")
            assert r_iso.status_code == 404

            # 2. Port 8888 Admin APIs reject unauthenticated requests
            r_unauth = await admin_cli.get("/api/stats")
            assert r_unauth.status_code == 401

            # 3. Clean request & O'Brien succeed and have hardened headers + masked Server banner
            r_obrien = await proxy_cli.get("/search?q=O'Brien")
            assert r_obrien.status_code == 200
            assert "Patrick O'Brien" in r_obrien.text
            assert "server" not in {k.lower() for k in r_obrien.headers.keys()}
            assert r_obrien.headers.get("x-frame-options") == "DENY"

            # 4. Malicious SQLi blocked (403) before reaching Target Web
            hits_before = target_app.state.backend_requests_received
            r_sqli = await proxy_cli.get("/search?q=1' UNION SELECT 1,2,3,4--", headers={"accept": "application/json"})
            assert r_sqli.status_code == 403
            assert target_app.state.backend_requests_received == hits_before
            assert len(runtime.telegram_sent_log) == 1
            # Redacted telegram alert must not contain raw UNION payload
            assert "UNION SELECT" not in runtime.telegram_sent_log[0]

            # 5. Admin authenticated stats & mode switch & Auto-Ban + Unban flow
            auth_hdr = {"X-Admin-Token": runtime.admin_token}
            r_stats = await admin_cli.get("/api/stats", headers=auth_hdr)
            assert r_stats.status_code == 200
            assert r_stats.json()["blocked_count"] == 1

            # Trigger 2 more blocks -> 3rd triggers Auto-Ban (403 even on clean /search)
            await proxy_cli.get("/search?q=1' OR 1=1--")
            await proxy_cli.get("/comments?msg=<script>alert(1)</script>")
            r_banned_clean = await proxy_cli.get("/search?q=SV001")
            assert r_banned_clean.status_code == 403

            # Admin Unbans 127.0.0.1 -> clean access restored
            r_unban = await admin_cli.post("/api/unban", json={"ip": "127.0.0.1"}, headers=auth_hdr)
            assert r_unban.status_code == 200
            r_restored = await proxy_cli.get("/search?q=SV001")
            assert r_restored.status_code == 200
    finally:
        await upstream_client.aclose()
