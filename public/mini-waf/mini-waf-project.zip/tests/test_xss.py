"""
test_xss.py - Unit Tests for XSS & Path Traversal Detection (Khánh & Hùng).
Covers script/svg/onerror payloads, double URL/HTML entities, traversal bypasses,
and benign math comparison edge cases (5 < 10).
"""

from waf.inspection.engine import InspectionEngine


def test_xss_vectors_blocked():
    engine = InspectionEngine()
    payloads = [
        "/comments?msg=<script>alert(1)</script>",
        "/comments?msg=<img src=x onerror=alert(document.cookie)>",
        "/comments?msg=<svg onload=alert(1)>",
        "/comments?msg=%253Cscript%253Ealert(1)%253C/script%253E",
        "/comments?msg=%26lt%3Bscript%26gt%3Balert(1)%26lt%3B/script%26gt%3B",
        "/comments?msg=javascript:alert(1)",
    ]
    for full in payloads:
        path, _, query = full.partition("?")
        dec = engine.inspect("GET", path, raw_query=query, waf_mode="BLOCKING")
        assert dec.action == "BLOCK", f"Failed to block XSS {full}: {dec}"
        assert "XSS-01" in dec.rule_ids


def test_traversal_and_null_byte_blocked():
    engine = InspectionEngine()
    for q in ("file=../../etc/passwd", "file=....//....//etc/passwd", "file=tailieu.pdf%00.jpg"):
        dec = engine.inspect("GET", "/download", raw_query=q, waf_mode="BLOCKING")
        assert dec.action == "BLOCK", f"Failed to block traversal {q}: {dec}"
        assert "LFI-01" in dec.rule_ids


def test_math_comparisons_and_clean_html_prose_allowed():
    engine = InspectionEngine()
    for q in ("msg=5%20%3C%2010", "msg=a%20%3C%20b%20and%20gpa%20%3E%208.0", "file=tailieu.pdf"):
        dec = engine.inspect("GET", "/comments", raw_query=q, waf_mode="BLOCKING")
        assert dec.action == "ALLOW", f"False positive on '{q}': {dec}"
