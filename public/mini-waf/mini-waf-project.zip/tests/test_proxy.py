"""
test_proxy.py - End-to-End Proxy, Target Web (VULNERABLE vs HARDENED), Control-Plane Auth,
Auto-Ban + Unban, and Response Hardening Verification (Khánh & Sơn & Quyết).
"""

from pathlib import Path

import httpx
import pytest

from target_web.app import create_target_app
from waf.monitoring.dashboard import create_admin_app
from waf.proxy.forward import WafRuntime
from waf.proxy.server import create_proxy_app


@pytest.mark.anyio
async def test_vulnerable_vs_hardened_target_web_defense_in_depth(tmp_path: Path):
    """Verify why target_web needs both WAF AND HARDENED Secure Coding (Defense-in-Depth)."""
    vuln_app = create_target_app(db_path=tmp_path / "vuln.db", docs_dir=tmp_path / "docs_v", security_mode="VULNERABLE")
    hard_app = create_target_app(db_path=tmp_path / "hard.db", docs_dir=tmp_path / "docs_h", security_mode="HARDENED")

    async with (
        httpx.AsyncClient(base_url="http://vuln:8000", transport=httpx.ASGITransport(app=vuln_app)) as c_vuln,
        httpx.AsyncClient(base_url="http://hard:8000", transport=httpx.ASGITransport(app=hard_app)) as c_hard,
    ):
        # 1. Without WAF, VULNERABLE mode suffers SQL syntax exposure on /grades and raw XSS reflection on /comments
        r_v_sqli = await c_vuln.get("/grades?masv=1'")
        r_v_xss = await c_vuln.get("/comments?msg=<script>alert(1)</script>")
        assert r_v_sqli.status_code == 500
        assert "<script>alert(1)</script>" in r_v_xss.text

        # 2. HARDENED mode blocks SQL injection at query binding and escapes HTML output
        r_h_sqli = await c_hard.get("/grades?masv=1'")
        r_h_xss = await c_hard.get("/comments?msg=<script>alert(1)</script>")
        r_h_lfi = await c_hard.get("/download?file=../../etc/passwd")
        assert r_h_sqli.status_code == 200
        assert "&lt;script&gt;alert(1)&lt;/script&gt;" in r_h_xss.text
        assert r_h_lfi.status_code == 400


@pytest.mark.anyio
async def test_proxy_end_to_end_isolation_autoban_and_unban(tmp_path: Path):
    target_app = create_target_app(db_path=tmp_path / "target.db", docs_dir=tmp_path / "docs", security_mode="VULNERABLE")
    upstream_client = httpx.AsyncClient(base_url="http://target_web:8000", transport=httpx.ASGITransport(app=target_app))
    runtime = WafRuntime.from_env(db_path=str(tmp_path / "waf.db"), http_client=upstream_client)
    proxy_app = create_proxy_app(runtime)
    admin_app = create_admin_app(runtime)

    try:
        async with (
            httpx.AsyncClient(base_url="http://proxy:8080", transport=httpx.ASGITransport(app=proxy_app)) as proxy_cli,
            httpx.AsyncClient(base_url="http://admin:8888", transport=httpx.ASGITransport(app=admin_app)) as admin_cli,
        ):
            # Admin endpoints isolated off port 8080 & gated on port 8888
            assert (await proxy_cli.get("/api/stats")).status_code == 404
            assert (await admin_cli.get("/api/stats")).status_code == 401

            # O'Brien passes through Proxy -> Student Portal 200 OK with scrubbed headers
            r_obrien = await proxy_cli.get("/search?q=O'Brien")
            assert r_obrien.status_code == 200
            assert "Patrick O'Brien" in r_obrien.text
            assert "server" not in {k.lower() for k in r_obrien.headers.keys()}
            assert r_obrien.headers.get("x-frame-options") == "DENY"

            # SQLi blocked before reaching backend + Redacted Telegram event recorded
            hits_before = target_app.state.backend_requests_received
            r_sqli = await proxy_cli.get("/grades?masv=1' UNION SELECT 1,2,3,4--", headers={"accept": "application/json"})
            assert r_sqli.status_code == 403
            assert target_app.state.backend_requests_received == hits_before
            assert len(runtime.telegram_sent_log) == 1
            assert "UNION SELECT" not in runtime.telegram_sent_log[0]

            # Two more violations trigger Auto-Ban -> clean /search blocked until Admin Unban
            await proxy_cli.get("/grades?masv=1' OR 1=1--")
            await proxy_cli.get("/comments?msg=<script>alert(1)</script>")
            assert (await proxy_cli.get("/search?q=SV001")).status_code == 403

            auth_hdr = {"X-Admin-Token": runtime.admin_token}
            assert (await admin_cli.post("/api/unban", json={"ip": "127.0.0.1"}, headers=auth_hdr)).status_code == 200
            assert (await proxy_cli.get("/search?q=SV001")).status_code == 200
    finally:
        await upstream_client.aclose()
