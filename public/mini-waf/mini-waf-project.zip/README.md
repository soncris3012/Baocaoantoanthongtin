# Mini-WAF Active Web Defense Project

Hệ thống Tường lửa Ứng dụng Web Chủ động (**Mini-WAF**) kết hợp Reverse Proxy bất đồng bộ (`FastAPI` + `HTTPX`), chuỗi chuẩn hóa chống né bộ lọc + SQL Lexical Tokenizer, Phòng thủ Chủ động (`Rate Limiting` Sliding/Fixed Window + `Auto-Ban` TTL), Dashboard tách cổng `:8888` có xác thực, cảnh báo Telegram bất đồng bộ và bộ đo kiểm định lượng (`benchmark/`).

## Cấu trúc Thư mục & Phân công Git 4 Thành viên

```text
mini-waf-project/
├── docker-compose.yml              # Sơn: Cô lập 2 mạng frontend_net & backend_net (internal=true)
├── .env.example                    # Cấu hình chung (UPSTREAM_URL, WAF_MODE, ADMIN_TOKEN)
├── SPECIFICATION_V2.md             # Đặc tả hợp nhất xử lý toàn bộ điểm phản biện
├── waf/
│   ├── Dockerfile                  # Sơn: Non-root user 1001, read-only friendly
│   ├── main.py                     # Sơn: Dual-plane ASGI (:8080 Proxy + 127.0.0.1:8888 Admin)
│   ├── rules.json                  # Hùng: Bộ quy tắc cộng điểm Anomaly Scoring (ngưỡng >= 5)
│   ├── proxy/forward.py            # Sơn: Async Reverse Proxy, 5xx scrubbing & header hardening
│   ├── protection/                 # Sơn: client_ip.py (XFF guard), rate_limit.py, blacklist.py, defense.py
│   ├── inspection/                 # Hùng: parser.py (HPP/JSON), normalizer.py, sql_lexer.py, engine.py
│   ├── database/                   # Quyết: models.py, repository.py (aiosqlite WAL)
│   ├── monitoring/                 # Quyết: logger.py (PII masking), telegram_alert.py, dashboard.py
│   └── templates/dashboard.html    # Quyết: Dashboard giám sát thời gian thực (:8888)
├── target_web/app.py               # Khánh: Website Quản lý Điểm Sinh viên (:8000, vulnerable/secure toggle)
├── benchmark/
│   ├── dataset.json                # Khánh: 100 mẫu chuẩn hóa (50 tấn công + 50 hợp lệ biên O'Brien)
│   └── run_benchmark.py            # Khánh: Đo TP/FP/TN/FN, Precision/Recall/F1, Mean/Median/p95 Latency
└── tests/                          # Bộ 9 ca kiểm thử đơn vị & tích hợp End-to-End
```

## Chạy nhanh trên Máy Local (macOS / Ubuntu)

```bash
# 1. Cài đặt môi trường ảo Python
python3 -m venv .venv && .venv/bin/pip install -r waf/requirements.txt

# 2. Chạy toàn bộ Unit Test & End-to-End
.venv/bin/pytest -v

# 3. Chạy Benchmark đo Precision / Recall / F1 / Latency (OFF vs MONITOR vs BLOCKING)
PYTHONPATH=. .venv/bin/python -m benchmark.run_benchmark --iterations 3

# 4. Hoặc chạy đồng thời Target Web (:8000) và Mini-WAF (:8080 Proxy + :8888 Dashboard)
PYTHONPATH=. .venv/bin/python target_web/app.py &
PYTHONPATH=. WAF_DB_PATH=/tmp/waf_logs.db .venv/bin/python waf/main.py
```

## Chạy bằng Docker Compose (Cách ly Hoàn toàn Máy chủ Đích)

```bash
cp .env.example .env
# Chế độ mặc định bảo vệ Website Quản lý Điểm Sinh viên (cổng 8000 nội bộ)
docker compose up --build -d

# Hoặc chuyển đổi sang mục tiêu DVWA trong mạng backend_net nội bộ
UPSTREAM_URL=http://dvwa:80 docker compose --profile dvwa up --build -d
```

Truy cập:
- **Ứng dụng qua Mini-WAF:** `http://127.0.0.1:8080`
- **Admin Dashboard (tách cổng & có mật khẩu `ADMIN_PASSWORD`):** `http://127.0.0.1:8888`
