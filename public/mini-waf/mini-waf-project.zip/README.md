# Mini-WAF Active Web Defense Project

Hệ thống Tường lửa Ứng dụng Web Chủ động (**Mini-WAF**) kết hợp **Web Demo 2 chế độ (`VULNERABLE` / `HARDENED`)**, **Reverse Proxy bất đồng bộ (`:8080`)**, **Inspection Engine (`parser`, `normalizer`, `sqli`, `xss`, `traversal`, `engine`)**, **Phòng thủ Hành vi & Dashboard tách cổng `:8888`**, cùng **Bộ Kiểm thử & Đo kiểm Định lượng (`tests/`)**.

## Cấu trúc Thư mục & Phân công 4 Thành viên

```text
mini-waf-project/
├── docker-compose.yml              # Sơn: Cô lập frontend_net & backend_net (internal=true)
├── target_web/app.py               # Sơn: Web Quản lý Điểm Sinh viên (:8000) — 2 chế độ VULNERABLE / HARDENED
├── waf/
│   ├── main.py                     # Sơn: Dual-plane ASGI (:8080 Proxy + 127.0.0.1:8888 Admin)
│   ├── proxy/
│   │   ├── server.py               # Sơn: Reverse Proxy FastAPI Request Pipeline
│   │   └── forward.py              # Sơn: HTTPX Async Forwarding, 5xx Scrubbing & Header Hardening
│   ├── inspection/
│   │   ├── parser.py               # Hùng: Tách Method, Path, Query/HPP, Body Form/JSON lồng nhau
│   │   ├── normalizer.py           # Hùng: Decode URL 3 tầng, HTML entity, NFKC, gỡ comment SQL
│   │   ├── sqli.py                 # Hùng: Regex + SQL Lexical Tokenizer (0% chặn nhầm O'Brien)
│   │   ├── xss.py                  # Hùng: Kiểm tra thẻ/sự kiện XSS tránh nhầm biểu thức toán học
│   │   ├── traversal.py            # Hùng: Path Traversal (../, ....//), Null-byte & Scanner signals
│   │   └── engine.py               # Hùng: Chấm điểm Anomaly Scoring (ngưỡng >= 5)
│   ├── protection/
│   │   ├── rate_limit.py           # Quyết: So sánh Fixed Window vs Sliding Window (deque)
│   │   ├── blacklist.py            # Quyết: Auto-Ban TTL O(1) RAM + Unban thủ công
│   │   └── decision.py             # Quyết: Structured Decision + X-Forwarded-For anti-spoofing
│   ├── database/                   # Quyết: models.py & repository.py (SQLite WAL)
│   └── monitoring/                 # Quyết: logger.py (Masking PII), dashboard.py, telegram_alert.py
└── tests/
    ├── test_sqli.py                # Khánh: Kiểm thử SQLi chuẩn & bypass + ca biên O'Brien
    ├── test_xss.py                 # Khánh: Kiểm thử XSS, Traversal & toán học 5 < 10
    ├── test_proxy.py               # Khánh: Đối chứng VULNERABLE vs HARDENED, E2E Proxy & Unban
    ├── test_defense.py             # Khánh & Quyết: Sliding Window burst, TTL, XFF, Header Scrubbing
    └── benchmark.py                # Khánh: Đo Precision, Recall, F1, Mean/Median/p95 Latency trên 100 mẫu
```

## Chạy Kiểm thử & Đo kiểm (macOS / Ubuntu)

```bash
python3 -m venv .venv && .venv/bin/pip install -r waf/requirements.txt

# Chạy toàn bộ 13 ca kiểm thử (test_sqli, test_xss, test_proxy, test_defense)
.venv/bin/pytest -v

# Chạy Benchmark 100 mẫu (Không WAF OFF vs Có WAF BLOCKING)
PYTHONPATH=. .venv/bin/python -m tests.benchmark --iterations 3
```
